<?php
/**
 * The header for our theme.
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package autoser
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="">
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">

<?php wp_head(); ?>
    
</head>

<body <?php body_class(); ?>>
    <div id="wrapper" <?php if( autoser_get_option('preload') ) echo 'class="animsition"'; ?>>

        <div id="site-header-wrap" <?php if( autoser_get_option('home_only') && autoser_get_option('header_style') == 'h3' ) echo 'class="home-only"'; ?>>

            <?php if(autoser_get_option('tbar')) { ?>
            <div id="top-bar">
                <div id="top-bar-inner" class="wprt-container">
                    <div class="top-bar-inner-wrap">
                        <div class="top-bar-content">
                            <?php $infos = autoser_get_option( 'topinfo', array() ); if($infos) { ?> 
                                <?php foreach ( $infos as $info ) { ?>
                                    <span class="content"><i class="fa <?php echo esc_attr($info['icon']); ?>"></i> <?php echo wp_specialchars_decode($info['text']); ?></span>
                                <?php } ?>
                            <?php } ?>
                        </div>

                        <div class="top-bar-socials">
                            <div class="inner">
                                <span class="icons">
                                    <?php $socials = autoser_get_option( 'socials', array() ); foreach ( $socials as $social ) { ?>
                                        <a<?php if($social['nwin']) echo ' target="_blank"'; ?> href="<?php echo esc_url($social['link']); ?>">
                                            <span class="fa <?php echo esc_attr($social['icon']); ?>"></span>
                                        </a>
                                    <?php } ?>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php } ?>

            <?php 
                $layout = autoser_get_option('header_style'); 
                if( $layout == 'h2' ) { 
                    get_template_part('framework/headers/header-2');
                }elseif( $layout == 'h3' ) { 
                    get_template_part('framework/headers/header-3');
                }else{
                    get_template_part('framework/headers/header-1');
                }

            ?>

        </div>