<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package autoser
 */
get_header(); 

?>

<?php if(autoser_get_option('page_header')) { ?>
<div id="featured-title" class="clearfix featured-title-left">
    <div id="featured-title-inner" class="wprt-container clearfix">
        <div class="featured-title-inner-wrap">
            <div class="featured-title-heading-wrap">
                <h1 class="featured-title-heading"><?php the_title(); ?></h1>
            </div>
            
            <?php if(autoser_get_option('breadcrumb') && function_exists('bcn_display')){ ?>
            <div id="breadcrumbs">
                <div class="breadcrumbs-inner">
                    <div class="breadcrumb-trail">
                        <?php bcn_display(); ?>
                    </div>
                </div>
            </div>
            <?php } ?>
        </div>
    </div>
</div>
<?php } ?>

<div id="main-content" class="site-main clearfix">
    <div id="content-wrap" class="wprt-container">
        <div id="site-content" class="site-content clearfix">
            <div id="inner-content" class="inner-content-wrap">
                <?php while (have_posts()) : the_post(); ?>
                    <?php the_post_thumbnail() ?>
                    <?php the_content(); ?>
                    <?php
                        wp_link_pages( array(
                            'before'      => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', 'autoser' ) . '</span>',
                            'after'       => '</div>',
                            'link_before' => '<span>',
                            'link_after'  => '</span>',
                            'pagelink'    => '<span class="screen-reader-text">' . esc_html__( 'Page', 'autoser' ) . ' </span>%',
                            'separator'   => '<span class="screen-reader-text">, </span>',
                        ) );
                    ?>
                    
                    <?php
                        if ( comments_open() || get_comments_number() ) :
                            comments_template();
                        endif;
                    ?>      
                <?php endwhile; ?>
                <div class="wprt-pagination clearfix">
                    <?php echo autoser_pagination(); ?> 
                </div>

            </div>
        </div>
        <div id="sidebar">
            <div id="inner-sidebar" class="inner-content-wrap">
                <?php get_sidebar();?>
            </div>
        </div>
    </div>
</div>
    
<?php get_footer(); ?>