<?php

/**
 * Register meta boxes
 *
 * @since 1.0
 *
 * @param array $meta_boxes
 *
 * @return array
 */

function autoser_register_meta_boxes( $meta_boxes ) {

	$prefix = '_cmb_';
	$meta_boxes[] = array(

		'id'       => 'format_detail',

		'title'    => esc_html__( 'Format Details', 'autoser' ),

		'pages'    => array( 'post' ),

		'context'  => 'normal',

		'priority' => 'high',

		'autosave' => true,

		'fields'   => array(

			array(

				'name'             => esc_html__( 'Image', 'autoser' ),

				'id'               => $prefix . 'image',

				'type'             => 'image_advanced',

				'class'            => 'image',

				'max_file_uploads' => 1,

			),

			array(

				'name'  => esc_html__( 'Gallery', 'autoser' ),

				'id'    => $prefix . 'images',

				'type'  => 'image_advanced',

				'class' => 'gallery',

			),			

			array(

				'name'  => esc_html__( 'Audio', 'autoser' ),

				'id'    => $prefix . 'link_audio',

				'type'  => 'oembed',

				'cols'  => 20,

				'rows'  => 2,

				'class' => 'audio',

				'desc' => 'Ex: https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/139083759',

			),

			array(

				'name'  => esc_html__( 'Video', 'autoser' ),

				'id'    => $prefix . 'link_video',

				'type'  => 'oembed',

				'cols'  => 20,

				'rows'  => 2,

				'class' => 'video',

				'desc' => 'Example: <b>https://player.vimeo.com/video/92505328</b>',

			),			

		),

	);

	$meta_boxes[] = array(
		'id'         => 'job_team',
		'title'      => 'Team Details',
		'pages'      => array( 'team' ), // Post type
		'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
		'fields' => array(			
            array(
                'name' => 'Job or Extra Text',
                'id'   => $prefix . 'job_team',
                'type' => 'text',
            ),
            array(
				'name'  => 'Facebook',
				'id'    => $prefix . 'team_fb',
				'type'  => 'text',
			), 
			array(
				'name'  => 'Twitter',
				'id'    => $prefix . 'team_tt',
				'type'  => 'text',
			),  
			array(
				'name'  => 'Linkedin',
				'id'    => $prefix . 'team_li',
				'type'  => 'text',
			), 
			array(
				'name'  => 'Google+',
				'id'    => $prefix . 'team_gg',
				'type'  => 'text',
			),
			array(
				'name'  => 'Instagram',
				'id'    => $prefix . 'team_in',
				'type'  => 'text',
			),
			array(
				'name'  => 'Other Social Link',
				'id'    => $prefix . 'link_soc',
				'type'  => 'text',
			), 
			array(
				'name'  => 'Other Social Icon',
				'desc'	=> 'Find icon class: <a target="_blank" href="https://fontawesome.com/v4.7.0/icons/">here</a>',
				'id'    => $prefix . 'icon_soc',
				'type'  => 'text',
			),
		)
	);
	

	return $meta_boxes;
}
add_filter( 'rwmb_meta_boxes', 'autoser_register_meta_boxes' );

