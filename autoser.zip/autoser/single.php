<?php
/**
 * The template for displaying all single posts.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package autoser
 */
get_header(); ?>

<?php if(autoser_get_option('page_header')) { $title    = autoser_get_option( 'title_single' ); ?>
<div id="featured-title" class="clearfix featured-title-left">
    <div id="featured-title-inner" class="wprt-container clearfix">
        <div class="featured-title-inner-wrap">
            <div class="featured-title-heading-wrap">
                <h1 class="featured-title-heading"><?php if($title) echo esc_html($title); else echo esc_html__('Single Blog', 'autoser'); ?></h1>
            </div>
            
            <?php if(autoser_get_option('breadcrumb') && function_exists('bcn_display')){ ?>
            <div id="breadcrumbs">
                <div class="breadcrumbs-inner">
                    <div class="breadcrumb-trail">
                        <?php bcn_display(); ?>
                    </div>
                </div>
            </div>
            <?php } ?>
        </div>
    </div>
</div>
<?php } ?>

<?php while (have_posts()): the_post(); $type = autoser_get_option('post_layout'); ?>

<div id="main-content" class="site-main clearfix">
    <div id="content-wrap" class="wprt-container <?php echo esc_attr($type); ?>">
        <div id="site-content" class="site-content clearfix">
            <div id="inner-content" class="inner-content-wrap">
                <?php                                                     
                    $format = get_post_format();
                    if( function_exists( 'rwmb_meta' ) ) {
                        $link_video = get_post_meta(get_the_ID(),'_cmb_link_video', true);
                        $image = rwmb_meta( '_cmb_image', "type=image" );
                    }
                ?>
                <div class="hentry">
                    <?php if($format == 'video') {  ?>
                    <div class="post-media clearfix">
                        <div class="embed-responsive embed-responsive-16by9">
                            <iframe width="100%" height="315" src="<?php echo esc_url( $link_video ); ?>"></iframe>
                        </div>
                    </div>
                    <?php }elseif($format == 'image') { ?>

                        <?php if($image){ ?>
                        <div class="post-media clearfix">
                            <?php foreach ( $image as $imag ) {  ?>
                                <?php $img = $imag['full_url']; ?>
                                <img src="<?php echo esc_url($img); ?>" alt="">
                            <?php } ?>
                        </div>
                        <?php } ?>

                    <?php }elseif( has_post_thumbnail() ) { ?>

                        <div class="post-media clearfix">            
                            <img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id()); ?>" alt="">
                        </div>

                    <?php } ?>
                    <div class="post-content-single-wrap">
                        <h2 class="post-title"><?php the_title(); ?></h2>

                        <div class="post-meta style-2">
                            <div class="post-meta-content">
                                <div class="post-meta-content-inner">
                                    <span class="post-by-author item">
                                        <span class="inner"><?php the_author_posts_link(); ?></span>
                                    </span>

                                    <span class="post-date item">
                                        <span class="inner"><span class="entry-date"><?php the_time( get_option( 'date_format' ) ); ?></span></span>
                                    </span>

                                    <span class="post-comment item">
                                        <span class="inner"><?php comments_number( esc_html__('0 comments', 'autoser'), esc_html__('1 comment', 'autoser'), __('% comments', 'autoser') ); ?></span>
                                    </span>
                                    <?php if(has_category()) { ?>
                                    <span class="post-meta-categories item">
                                        <span class="inner">
                                            <?php the_category( ', ' ); ?>
                                        </span>
                                    </span>
                                    <?php } ?>
                                </div>
                            </div>
                        </div>

                        <?php the_content(); ?>

                        <?php if(has_tag()) { the_tags( '<div class="post-tags">', '', '</div>' ); } ?>

                        <?php
                            wp_link_pages( array(
                                'before'      => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', 'autoser' ) . '</span>',
                                'after'       => '</div>',
                                'link_before' => '<span>',
                                'link_after'  => '</span>',
                                'pagelink'    => '<span class="screen-reader-text">' . esc_html__( 'Page', 'autoser' ) . ' </span>%',
                                'separator'   => '<span class="screen-reader-text">, </span>',
                            ) );
                        ?>
                    </div>

                </div>

                <div class="comment-section">
                    <?php
                       if ( comments_open() || get_comments_number() ) :
                        comments_template();
                       endif;
                    ?>
                </div>

            </div>

        </div>

        <?php if( $type != 'no-bar' ) { ?>
        <div id="sidebar">
            <div id="inner-sidebar" class="inner-content-wrap">
                <?php get_sidebar();?>
            </div>
        </div>
        <?php } ?>
    </div>
</div>

<?php endwhile; ?>

<?php get_footer(); ?>