<article class="hentry <?php post_class(); ?>">
    <?php if( function_exists( 'rwmb_meta' ) ) { ?>
        <?php $link_video = get_post_meta(get_the_ID(),'_cmb_link_video', true); if($link_video) { ?>
        <div class="post-media clearfix">
            <div class="embed-responsive embed-responsive-16by9">
                <iframe width="100%" height="315" src="<?php echo esc_url( $link_video ); ?>"></iframe>
            </div>
        </div>
    <?php } } ?>

    <div class="post-content-wrap">
        <h2 class="post-title">
            <span class="post-title-inner">
                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
            </span>
        </h2><!-- /.post-title -->

        <div class="post-meta style-2">
            <div class="post-meta-content">
                <div class="post-meta-content-inner">
                    <span class="post-by-author item">
                        <span class="inner"><?php the_author_posts_link(); ?></span>
                    </span>

                    <span class="post-date item">
                        <span class="inner"><span class="entry-date"><?php the_time( get_option( 'date_format' ) ); ?></span></span>
                    </span>

                    <span class="post-comment item">
                        <span class="inner"><?php comments_number( esc_html__('0 comments', 'autoser'), esc_html__('1 comment', 'autoser'), __('% comments', 'autoser') ); ?></span>
                    </span>
                    <?php if(has_category()) { ?>
                    <span class="post-meta-categories item">
                        <span class="inner">
                            <?php the_category( ', ' ); ?>
                        </span>
                    </span>
                    <?php } ?>
                </div>
            </div>
        </div><!-- /.post-meta -->

        <div class="post-content post-excerpt">
            <p><?php echo autoser_excerpt_length(); ?></p>
        </div><!-- /.post-excerpt -->

        <div class="post-read-more">
            <div class="post-link">
                <a href="<?php the_permalink(); ?>"><?php if(autoser_get_option('readmore_btn')){echo esc_html(autoser_get_option('readmore_btn'));}else{ esc_html_e('Read More', 'autoser'); } ?></a>
            </div>
        </div><!-- /.post-read-more -->
    </div><!-- /.post-content-wrap -->
</article>