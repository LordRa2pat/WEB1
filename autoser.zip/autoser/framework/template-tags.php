<?php
/**
 * Custom template tags for this theme.
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package autoser
 */


/**** Change length of the excerpt ****/
if ( ! function_exists( 'autoser_excerpt_length' ) ) :
function autoser_excerpt_length() {
  
  if(autoser_get_option('excerpt_length')){
    $limit = autoser_get_option('excerpt_length');
  }else{
    $limit = 30;
  }  
  $excerpt = explode(' ', get_the_excerpt(), $limit);

  if (count($excerpt)>=$limit) {
    array_pop($excerpt);
    $excerpt = implode(" ",$excerpt).'...';
  } else {
    $excerpt = implode(" ",$excerpt);
  } 
  $excerpt = preg_replace('`[[^]]*]`','',$excerpt);
  return $excerpt;

}
endif;

/** Excerpt Section Blog Post **/
if ( ! function_exists( 'autoser_excerpt' ) ) :
function autoser_excerpt($limit) {
  $excerpt = explode(' ', get_the_excerpt(), $limit);
  if (count($excerpt)>=$limit) {
    array_pop($excerpt);
    $excerpt = implode(" ",$excerpt).'...';
  } else {
    $excerpt = implode(" ",$excerpt);
  }
  $excerpt = preg_replace('`[[^]]*]`','',$excerpt);
  return $excerpt;
}
endif;

/**Custom function tag widgets**/
if ( ! function_exists( 'autoser_tag_cloud_widget' ) ) :
  function autoser_tag_cloud_widget($args) {
    $args['number'] = 0; //adding a 0 will display all tags
    $args['largest'] = 18; //largest tag
    $args['smallest'] = 14; //smallest tag
    $args['unit'] = 'px'; //tag font unit
    $args['format'] = 'list'; //ul with a class of wp-tag-cloud
    $args['exclude'] = array(20, 80, 92); //exclude tags by ID
    return $args;
  }
  add_filter( 'widget_tag_cloud_args', 'autoser_tag_cloud_widget' );
endif;

/** Excerpt Section Blog Post **/
function autoser_blog_excerpt($limit) {
  $excerpt = explode(' ', get_the_excerpt(), $limit);
  if (count($excerpt)>=$limit) {
    array_pop($excerpt);
    $excerpt = implode(" ",$excerpt).'...';
  } else {
    $excerpt = implode(" ",$excerpt);
  }
  $excerpt = preg_replace('`[[^]]*]`','',$excerpt);
  return $excerpt;
}

/** Pagination **/
if ( ! function_exists( 'autoser_pagination' ) ) :
function autoser_pagination($prev = '<i class="fa fa-angle-double-left"></i>', $next = '<i class="fa fa-angle-double-right"></i>', $pages='') {
  global $wp_query, $wp_rewrite;
  $wp_query->query_vars['paged'] > 1 ? $current = $wp_query->query_vars['paged'] : $current = 1;
  if($pages==''){
    global $wp_query;
    $pages = $wp_query->max_num_pages;
    if(!$pages)
    {
      $pages = 1;
    }
  }
  $pagination = array(
    'base'          => str_replace( 999999999, '%#%', get_pagenum_link( 999999999 ) ),
    'format'        => '',
    'current'       => max( 1, get_query_var('paged') ),
    'total'         => $pages,
    'prev_text'     => $prev,
    'next_text'     => $next,       
    'type'          => 'list',
    'end_size'      => 3,
    'mid_size'      => 3
);
  $return =  paginate_links( $pagination );
  echo str_replace( "<ul class='page-numbers'>", '<ul class="page-pagination">', $return );
}
endif;

/*Custom style backend*/
if ( ! function_exists( 'autoser_custom_wp_admin_style' ) ) :
function autoser_custom_wp_admin_style() {
  wp_register_style( 'autoser_custom_wp_admin_css', get_template_directory_uri() . '/framework/admin/css/admin-style.css', false, '1.0.0' );
  wp_register_style( 'autoser_newicons_admin_css', get_template_directory_uri() . '/assets/css/themecore-icons.css', false, '1.0.0' );
  wp_register_style( 'autoser_caricons_admin_css', get_template_directory_uri() . '/assets/css/carservice-icons.css', false, '1.0.0' );
  wp_enqueue_style( 'autoser_custom_wp_admin_css' );
  wp_enqueue_style( 'autoser_newicons_admin_css' );
  wp_enqueue_style( 'autoser_caricons_admin_css' );

  wp_enqueue_script( 'autoser-backend-js', get_template_directory_uri()."/framework/admin/js/admin-script.js", array( 'jquery' ), '1.0.0', true );
  wp_enqueue_script( 'autoser-backend-js' );
}
add_action( 'admin_enqueue_scripts', 'autoser_custom_wp_admin_style' );
endif;

/** Custom search form **/
if ( ! function_exists( 'autoser_search_form' ) ) :
function autoser_search_form( $form ) {
    $form = '<form role="search" method="get" action="' . esc_url(home_url( '/' )) . '" class="header-search-form search-form" >  
                <input type="text" id="s" class="header-search-field search-field" value="' . get_search_query() . '" name="s" placeholder="'.__('Type and hit enter...', 'autoser').'" />
                <button type="submit" class="header-search-submit search-submit"><em class="fa fa-search"></em></button>
            </form>';

    return $form;
}
add_filter( 'get_search_form', 'autoser_search_form' );
endif;

/* Custom comment List: */
function autoser_theme_comment($comment, $args, $depth) { 
   
  $GLOBALS['comment'] = $comment; ?>

  <li id="comment-<?php comment_ID(); ?>" class="comment-item">
    <article class="comment-wrap clearfix">

      <div class="gravatar">
        <?php echo get_avatar($comment,$size='60',$default='http://0.gravatar.com/avatar/ad516503a11cd5ca435acc9bb6523536?s=60' ); ?>
      </div>

      <div class="comment-content">
        <div class="comment-meta">
            <h6 class="comment-author"><?php printf(__('%s','autoser'), get_comment_author()) ?></h6>
            <span class="comment-time"><?php the_time( get_option( 'date_format' ) ); ?></span>
            <span class="comment-reply"><?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth']))) ?></span>
        </div>
        <div class="comment-text">
            <?php if ($comment->comment_approved == '0'){ ?>
              <em><?php _e('Your comment is awaiting moderation.','autoser') ?></em>
            <?php }else{ ?>
              <?php comment_text() ?>
            <?php } ?>
        </div>
      </div>

    </article> 
  </li>
  
<?php
}

/** Rewrite set up, when theme activate i mean **/
if (isset($_GET['activated']) && is_admin()) {
  global $wp_rewrite;
  $wp_rewrite->set_permalink_structure('/%postname%/');
  $wp_rewrite->flush_rules();
}

/** Remove Customizer **/
add_action( "customize_register", "autoser_customize_register" );
function autoser_customize_register( $wp_customize ) {
  $wp_customize->remove_section('header_image');
  $wp_customize->remove_section('background_image');
  $wp_customize->remove_section('colors');
}

/*Support Woocommerce*/
add_action( 'after_setup_theme', 'construct_woocommerce_support' );
function construct_woocommerce_support() {
    add_theme_support( 'woocommerce' );
}

/**Add more icons to awesome**/
add_filter( 'vc_iconpicker-type-fontawesome', 'autoser_vc_iconpicker_type_fontawesome' );

function autoser_vc_iconpicker_type_fontawesome( $icons ) {

  $fontawesome_icons = array(
    'Car Service' => array(
      array( 'as-icon-car-parts-29' => ' ' ),
      array( 'as-icon-car-parts-28' => ' ' ),
      array( 'as-icon-car-parts-27' => ' ' ),
      array( 'as-icon-car-parts-26' => ' ' ),
      array( 'as-icon-car-parts-25' => ' ' ),
      array( 'as-icon-car-parts-24' => ' ' ),
      array( 'as-icon-car-parts-23' => ' ' ),
      array( 'as-icon-car-parts-22' => ' ' ),
      array( 'as-icon-car-parts-21' => ' ' ),
      array( 'as-icon-car-parts-20' => ' ' ),
      array( 'as-icon-car-parts-19' => ' ' ),
      array( 'as-icon-car-parts-18' => ' ' ),
      array( 'as-icon-car-parts-17' => ' ' ),
      array( 'as-icon-car-parts-16' => ' ' ),
      array( 'as-icon-car-parts-15' => ' ' ),
      array( 'as-icon-car-parts-14' => ' ' ),
      array( 'as-icon-car-parts-13' => ' ' ),
      array( 'as-icon-car-parts-12' => ' ' ),
      array( 'as-icon-car-parts-11' => ' ' ),
      array( 'as-icon-car-parts-10' => ' ' ),
      array( 'as-icon-car-parts-9' => ' ' ),
      array( 'as-icon-car-parts-8' => ' ' ),
      array( 'as-icon-car-parts-7' => ' ' ),
      array( 'as-icon-car-parts-6' => ' ' ),
      array( 'as-icon-car-parts-5' => ' ' ),
      array( 'as-icon-car-parts-4' => ' ' ),
      array( 'as-icon-car-parts-3' => ' ' ),
      array( 'as-icon-car-parts-2' => ' ' ),
      array( 'as-icon-car-parts-1' => ' ' ),
      array( 'as-icon-car-parts' => ' ' ),
      array( 'as-icon-charter' => ' ' ),
      array( 'as-icon-clutch' => ' ' ),
      array( 'as-icon-disc-brake2' => ' ' ),
      array( 'as-icon-filter' => ' ' ),
      array( 'as-icon-generator' => ' ' ),
      array( 'as-icon-lamp' => ' ' ),
      array( 'as-icon-spark-plug2' => ' ' ),
      array( 'as-icon-steering-wheel3' => ' ' ),
      array( 'as-icon-suspension2' => ' ' ),
      array( 'as-icon-timing-belt2' => ' ' ),
      array( 'as-icon-gearshift-1' => ' ' ),
      array( 'as-icon-exhaust-pipe3' => ' ' ),
      array( 'as-icon-turbo' => ' ' ),
      array( 'as-icon-brake-2' => ' ' ),
      array( 'as-icon-alloy-wheel-1' => ' ' ),
      array( 'as-icon-alloy-wheel2' => ' ' ),
      array( 'as-icon-belt-3' => ' ' ),
      array( 'as-icon-speedometer2' => ' ' ),
      array( 'as-icon-car-engine-6' => ' ' ),
      array( 'as-icon-car-engine-5' => ' ' ),
      array( 'as-icon-car-engine-4' => ' ' ),
      array( 'as-icon-radiator-1' => ' ' ),
      array( 'as-icon-steering-wheel4' => ' ' ),
      array( 'as-icon-shock-absorber-1' => ' ' ),
      array( 'as-icon-chassis2' => ' ' ),
      array( 'as-icon-wheel2' => ' ' ),
      array( 'as-icon-battery3' => ' ' ),
      array( 'as-icon-car-engine-3' => ' ' ),
      array( 'as-icon-radiator3' => ' ' ),
      array( 'as-icon-crankshalf' => ' ' ),
      array( 'as-icon-brake-1' => ' ' ),
      array( 'as-icon-engine-2' => ' ' ),
      array( 'as-icon-gears2' => ' ' ),
      array( 'as-icon-gearshift' => ' ' ),
      array( 'as-icon-windscreen' => ' ' ),
      array( 'as-icon-power' => ' ' ),
      array( 'as-icon-shock-absorber2' => ' ' ),
      array( 'as-icon-brake' => ' ' ),
      array( 'as-icon-car-engine-2' => ' ' ),
      array( 'as-icon-gear' => ' ' ),
      array( 'as-icon-car-lights' => ' ' ),
      array( 'as-icon-pipe' => ' ' ),
      array( 'as-icon-car-engine-1' => ' ' ),
      array( 'as-icon-fan-1' => ' ' ),
      array( 'as-icon-cooler' => ' ' ),
      array( 'as-icon-tire2' => ' ' ),
      array( 'as-icon-piston-1' => ' ' ),
      array( 'as-icon-belt-2' => ' ' ),
      array( 'as-icon-fan' => ' ' ),
      array( 'as-icon-car-engine' => ' ' ),
      array( 'as-icon-spark-plug3' => ' ' ),
      array( 'as-icon-engine-1' => ' ' ),
      array( 'as-icon-suspension3' => ' ' ),
      array( 'as-icon-transmission' => ' ' ),
      array( 'as-icon-gasoline' => ' ' ),
      array( 'as-icon-belt-1' => ' ' ),
      array( 'as-icon-belt' => ' ' ),
      array( 'as-icon-piston3' => ' ' ),
      array( 'as-icon-engine2' => ' ' ),
      array( 'as-icon-air-filter2' => ' ' ),
      array( 'as-icon-air-refreshener' => ' ' ),
      array( 'as-icon-battery4' => ' ' ),
      array( 'as-icon-car2' => ' ' ),
      array( 'as-icon-car-1' => ' ' ),
      array( 'as-icon-car-breakdown' => ' ' ),
      array( 'as-icon-car-key' => ' ' ),
      array( 'as-icon-car-wash3' => ' ' ),
      array( 'as-icon-chassis3' => ' ' ),
      array( 'as-icon-cleaner' => ' ' ),
      array( 'as-icon-crane' => ' ' ),
      array( 'as-icon-dashboard' => ' ' ),
      array( 'as-icon-dices' => ' ' ),
      array( 'as-icon-dummy' => ' ' ),
      array( 'as-icon-engine3' => ' ' ),
      array( 'as-icon-exhaust-pipe4' => ' ' ),
      array( 'as-icon-funnel2' => ' ' ),
      array( 'as-icon-gasoline2' => ' ' ),
      array( 'as-icon-gas-station3' => ' ' ),
      array( 'as-icon-gearshift2' => ' ' ),
      array( 'as-icon-gearshift-12' => ' ' ),
      array( 'as-icon-hydraulic-jack' => ' ' ),
      array( 'as-icon-license-plate' => ' ' ),
      array( 'as-icon-mechanic2' => ' ' ),
      array( 'as-icon-oil3' => ' ' ),
      array( 'as-icon-pedals' => ' ' ),
      array( 'as-icon-piston4' => ' ' ),
      array( 'as-icon-pliers' => ' ' ),
      array( 'as-icon-rearview-mirror' => ' ' ),
      array( 'as-icon-reflective-triangle' => ' ' ),
      array( 'as-icon-route-66' => ' ' ),
      array( 'as-icon-seat-belt' => ' ' ),
      array( 'as-icon-spark' => ' ' ),
      array( 'as-icon-steering-wheel5' => ' ' ),
      array( 'as-icon-suspension4' => ' ' ),
      array( 'as-icon-toolbox' => ' ' ),
      array( 'as-icon-tools' => ' ' ),
      array( 'as-icon-voltmeter' => ' ' ),
      array( 'as-icon-wheel3' => ' ' ),
      array( 'as-icon-wiper' => ' ' ),
      array( 'as-icon-wrench' => ' ' ),
      array( 'as-icon-hours' => ' ' ),
      array( 'as-icon-aerosol' => ' ' ),
      array( 'as-icon-airbag' => ' ' ),
      array( 'as-icon-air-filter' => ' ' ),
      array( 'as-icon-autolift' => ' ' ),
      array( 'as-icon-automatic-wash-car' => ' ' ),
      array( 'as-icon-balancing' => ' ' ),
      array( 'as-icon-battery' => ' ' ),
      array( 'as-icon-brake-disk' => ' ' ),
      array( 'as-icon-car' => ' ' ),
      array( 'as-icon-car-painting' => ' ' ),
      array( 'as-icon-car-search' => ' ' ),
      array( 'as-icon-car-wash' => ' ' ),
      array( 'as-icon-chassis' => ' ' ),
      array( 'as-icon-cracked-windshield' => ' ' ),
      array( 'as-icon-cross-wrench' => ' ' ),
      array( 'as-icon-damage' => ' ' ),
      array( 'as-icon-electric-car' => ' ' ),
      array( 'as-icon-evacuator' => ' ' ),
      array( 'as-icon-exhaust-pipe' => ' ' ),
      array( 'as-icon-fix-sign' => ' ' ),
      array( 'as-icon-flat-tire' => ' ' ),
      array( 'as-icon-funnel' => ' ' ),
      array( 'as-icon-fuse' => ' ' ),
      array( 'as-icon-garage' => ' ' ),
      array( 'as-icon-gas-station' => ' ' ),
      array( 'as-icon-gears' => ' ' ),
      array( 'as-icon-hammer-and-wrench' => ' ' ),
      array( 'as-icon-headlight' => ' ' ),
      array( 'as-icon-jerrycan' => ' ' ),
      array( 'as-icon-key' => ' ' ),
      array( 'as-icon-mirror' => ' ' ),
      array( 'as-icon-motor' => ' ' ),
      array( 'as-icon-oil' => ' ' ),
      array( 'as-icon-piston' => ' ' ),
      array( 'as-icon-radiator' => ' ' ),
      array( 'as-icon-screwdriver-and-wrench' => ' ' ),
      array( 'as-icon-shock-absorber' => ' ' ),
      array( 'as-icon-signaling' => ' ' ),
      array( 'as-icon-spark-plug' => ' ' ),
      array( 'as-icon-steering-wheel' => ' ' ),
      array( 'as-icon-tachometer' => ' ' ),
      array( 'as-icon-tank' => ' ' ),
      array( 'as-icon-timing-belt' => ' ' ),
      array( 'as-icon-tinting' => ' ' ),
      array( 'as-icon-traffic-cone' => ' ' ),
      array( 'as-icon-transmision' => ' ' ),
      array( 'as-icon-voltage' => ' ' ),
      array( 'as-icon-wheel' => ' ' ),
      array( 'as-icon-wheel-and-manometer' => ' ' ),
      array( 'as-icon-air-conditioning' => ' ' ),
      array( 'as-icon-alloy-wheel' => ' ' ),
      array( 'as-icon-battery2' => ' ' ),
      array( 'as-icon-car-repair' => ' ' ),
      array( 'as-icon-car-wash2' => ' ' ),
      array( 'as-icon-diagnostic' => ' ' ),
      array( 'as-icon-disc-brake' => ' ' ),
      array( 'as-icon-electrical-service' => ' ' ),
      array( 'as-icon-engine' => ' ' ),
      array( 'as-icon-exhaust-pipe2' => ' ' ),
      array( 'as-icon-gas-station2' => ' ' ),
      array( 'as-icon-gearstick' => ' ' ),
      array( 'as-icon-ignition' => ' ' ),
      array( 'as-icon-inspection' => ' ' ),
      array( 'as-icon-key2' => ' ' ),
      array( 'as-icon-maintenance' => ' ' ),
      array( 'as-icon-mechanic' => ' ' ),
      array( 'as-icon-oil2' => ' ' ),
      array( 'as-icon-painting' => ' ' ),
      array( 'as-icon-piston2' => ' ' ),
      array( 'as-icon-radiator2' => ' ' ),
      array( 'as-icon-reparation' => ' ' ),
      array( 'as-icon-speedometer' => ' ' ),
      array( 'as-icon-steering-wheel2' => ' ' ),
      array( 'as-icon-suspension' => ' ' ),
      array( 'as-icon-tire' => ' ' ),
      array( 'as-icon-tire-1' => ' ' ),
      array( 'as-icon-trailer' => ' ' ),
      array( 'as-icon-wheel-alignment' => ' ' ),
      array( 'as-icon-windshield' => ' ' ),
    ),
    'OT Icons' => array(
      array( 'rt-icon-up-arrows-3'      => 'OT Icon' ),
      array( 'rt-icon-up-arrows-1'      => 'OT Icon' ),
      array( 'rt-icon-up-arrows-2'      => 'OT Icon' ),
      array( 'rt-icon-up-arrows-12'      => 'OT Icon' ),
      array( 'rt-icon-up-arrows'      => 'OT Icon' ),
      array( 'rt-icon-zoom-in-3'      => 'OT Icon' ),
      array( 'rt-icon-zoom-in-2'      => 'OT Icon' ),
      array( 'rt-icon-zoom-in-1'      => 'OT Icon' ),
      array( 'rt-icon-zoom-in'      => 'OT Icon' ),
      array( 'rt-icon-cart-2'      => 'OT Icon' ),
      array( 'rt-icon-cart-3'      => 'OT Icon' ),
      array( 'rt-icon-cart'      => 'OT Icon' ),
      array( 'rt-icon-magnifier6'      => 'OT Icon' ),
      array( 'rt-icon-play-button-3'      => 'OT Icon' ),
      array( 'rt-icon-placeholder'      => 'OT Icon' ),
      array( 'rt-icon-telephone'      => 'OT Icon' ),
      array( 'rt-icon-play-button-4'      => 'OT Icon' ),
      array( 'rt-icon-play-button-1'      => 'OT Icon' ),
      array( 'rt-icon-play-button'      => 'OT Icon' ),
      array( 'rt-icon-play-button-2'      => 'OT Icon' ),
      array( 'rt-icon-play'      => 'OT Icon' ),
      array( 'rt-icon-right-arrow-6'      => 'OT Icon' ),
      array( 'rt-icon-play-arrow'      => 'OT Icon' ),
      array( 'rt-icon-left-arrow12'      => 'OT Icon' ),
      array( 'rt-icon-right-arrow12'      => 'OT Icon' ),
      array( 'rt-icon-magnifier1'      => 'OT Icon' ),
      array( 'rt-icon-magnifier2'      => 'OT Icon' ),
      array( 'rt-icon-magnifier3'      => 'OT Icon' ),
      array( 'rt-icon-magnifier4'      => 'OT Icon' ),
      array( 'rt-icon-magnifier5'      => 'OT Icon' ),
      array( 'rt-icon-down-arrow'      => 'OT Icon' ),
      array( 'rt-icon-right-arrow'      => 'OT Icon' ),
      array( 'rt-icon-minus-circle'      => 'OT Icon' ),
      array( 'rt-icon-plus-circle'      => 'OT Icon' ),
      array( 'rt-icon-down-arrow-circle'      => 'OT Icon' ),
      array( 'rt-icon-right-arrow-circle'      => 'OT Icon' ),
      array( 'rt-icon-plus'      => 'OT Icon' ),
      array( 'rt-icon-minus'      => 'OT Icon' ),
      array( 'rt-icon-1-down'      => 'OT Icon' ),
      array( 'rt-icon-2-down'      => 'OT Icon' ),
      array( 'rt-icon-2-down-1'      => 'OT Icon' ),
      array( 'rt-icon-2-right'      => 'OT Icon' ),
      array( 'rt-icon-close-envelope'      => 'OT Icon' ),
      array( 'rt-icon-old-phone'      => 'OT Icon' ),
      array( 'rt-icon-4-time'      => 'OT Icon' ),
      array( 'rt-icon-4-user'      => 'OT Icon' ),
      array( 'rt-icon-4-address'      => 'OT Icon' ),
      array( 'rt-icon-4-cart'      => 'OT Icon' ),
      array( 'rt-icon-4-cat'      => 'OT Icon' ),
      array( 'rt-icon-4-comment'      => 'OT Icon' ),
      array( 'rt-icon-4-phone'      => 'OT Icon' ),
      array( 'rt-icon-4-search'      => 'OT Icon' ),
      array( 'rt-icon-home'      => 'OT Icon' ),
      array( 'rt-icon-3-user'      => 'OT Icon' ),
      array( 'rt-icon-3-address'      => 'OT Icon' ),
      array( 'rt-icon-3-cart'      => 'OT Icon' ),
      array( 'rt-icon-3-cat'      => 'OT Icon' ),
      array( 'rt-icon-3-comment'      => 'OT Icon' ),
      array( 'rt-icon-3-phone'      => 'OT Icon' ),
      array( 'rt-icon-3-search'      => 'OT Icon' ),
      array( 'rt-icon-3-time'      => 'OT Icon' ),
      array( 'rt-icon-1-address'      => 'OT Icon' ),
      array( 'rt-icon-1-phone'      => 'OT Icon' ),
      array( 'rt-icon-1-search'      => 'OT Icon' ),
      array( 'rt-icon-1-time'      => 'OT Icon' ),
      array( 'rt-icon-2-user'      => 'OT Icon' ),
      array( 'rt-icon-2-address'      => 'OT Icon' ),
      array( 'rt-icon-2-cart'      => 'OT Icon' ),
      array( 'rt-icon-2-cat'      => 'OT Icon' ),
      array( 'rt-icon-2-comment'      => 'OT Icon' ),
      array( 'rt-icon-2-phone'      => 'OT Icon' ),
      array( 'rt-icon-2-search'      => 'OT Icon' ),
      array( 'rt-icon-2-time'      => 'OT Icon' ),
      array( 'rt-icon-flickr'      => 'OT Icon' ),
      array( 'rt-icon-dribbble'      => 'OT Icon' ),
      array( 'rt-icon-behance'      => 'OT Icon' ),
      array( 'rt-icon-android'      => 'OT Icon' ),
      array( 'rt-icon-apple'      => 'OT Icon' ),
      array( 'rt-icon-skype'      => 'OT Icon' ),
      array( 'rt-icon-instagram'      => 'OT Icon' ),
      array( 'rt-icon-pinterest'      => 'OT Icon' ),
      array( 'rt-icon-linkedin'      => 'OT Icon' ),
      array( 'rt-icon-vimeo'      => 'OT Icon' ),
      array( 'rt-icon-youtube'      => 'OT Icon' ),
      array( 'rt-icon-google-plus'      => 'OT Icon' ),
      array( 'rt-icon-twitter'      => 'OT Icon' ),
      array( 'rt-icon-facebook'      => 'OT Icon' ),
      array( 'rt-icon-message-1'      => 'OT Icon' ),
      array( 'rt-icon-home2'      => 'OT Icon' ),
      array( 'rt-icon-calendar '      => 'OT Icon' ),
      array( 'rt-icon-chat2'      => 'OT Icon' ),
      array( 'rt-icon-user'      => 'OT Icon' ),
      array( 'rt-icon-folder'      => 'OT Icon' ),
      array( 'rt-icon-settings'      => 'OT Icon' ),
      array( 'rt-icon-message'      => 'OT Icon' ),
      array( 'rt-icon-placeholder2'      => 'OT Icon' ),
      array( 'rt-icon-alarm-clock'      => 'OT Icon' ),
      array( 'rt-icon-chat'      => 'OT Icon' ),
      array( 'rt-icon-bag'      => 'OT Icon' ),
      array( 'rt-icon-search2'      => 'OT Icon' ),
    ),
  );
  return array_merge( $icons, $fontawesome_icons );
}

/** Add specific CSS class by filter **/
add_filter( 'body_class', 'autoser_body_class_names', 999 );
function autoser_body_class_names( $classes ) {
  $theme = wp_get_theme();
  
  if( autoser_get_option('sticky') ){
    $classes[] = 'header-fixed';
  }
  if( autoser_get_option('header_style') == 'h3' && !autoser_get_option('home_only') ){
    $classes[] = 'header-style-2';
  }

  $classes[] = 'autoser-theme-ver-'.$theme->version;

  $classes[] = 'wordpress-version-'.get_bloginfo( 'version' );

  // return the $classes array
  return $classes;
}