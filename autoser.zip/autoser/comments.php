<?php
/**
 * The template for displaying comments.
 *
 * This is the template that displays the area of the page that contains both the current comments
 * and the comment form.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package autoser
 */

/*
 * If the current post is protected by a password and
 * the visitor has not yet entered the password we will
 * return early without loading the comments.
 */
if ( post_password_required() ) {
	return;
}
?>

<div id="comments" class="comments-area">
	

	<?php if ( have_comments() ) : ?>
		<div class="list-comments">
			<h2 class="comments-title"><?php comments_number( esc_html__('0 Comments', 'autoser'), esc_html__('1 Comment', 'autoser'), esc_html__('% Comments', 'autoser') ); ?></h2>
		    <ol class="comment-list">
					<?php wp_list_comments('callback=autoser_theme_comment'); ?>
				<?php
					// Are there comments to navigate through?
					if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) :
				?>
					<nav class="navigation comment-navigation" role="navigation">		   
						<div class="nav-previous"><?php previous_comments_link( esc_html__( '&larr; Older Comments', 'autoser' ) ); ?></div>
						<div class="nav-next"><?php next_comments_link( esc_html__( 'Newer Comments &rarr;', 'autoser' ) ); ?></div>
		                <div class="clearfix"></div>
					</nav><!-- .comment-navigation -->
				<?php endif; // Check for comment navigation ?>

				<?php if ( ! comments_open() && get_comments_number() ) : ?>
					<p class="no-comments"><?php esc_html_e( 'Comments are closed.' , 'autoser' ); ?></p>
				<?php endif; ?>	
		    </ol>
		</div>		
	<?php endif; ?>	

	<div class="form-message text-left">
	<?php
		$aria_req = ( $req ? " aria-required='true'" : '' );
        $comment_args = array(
                'id_form' 				=> 'reply-form',
                'title_reply_before'	=> '<h5 id="reply-title" class="comment-reply-title">',                              
                'title_reply_after'		=> '</h5>',                              
                'title_reply'   		=> esc_html__('Leave A Comment', 'autoser'),
                'fields' 				=> apply_filters( 'comment_form_default_fields', array(
                    'author' 			=> '<fieldset class="name-wrap"><input id="author" name="author" id="name" class="input-line" type="text" value="" placeholder="'. esc_html__( 'Name', 'autoser' ) .'" required></fieldset>',
                    'email' 			=> '<fieldset class="email-wrap"><input id="author" name="email" id="name" class="input-line" type="email" value="" placeholder="'. esc_html__( 'Email', 'autoser' ) .'" required></fieldset>',
                ) ),                                
                 'comment_field' 		=> '<fieldset class="message-wrap"><textarea required name="comment" '.$aria_req.' id="comment-message" class="txtarea input-line" aria-required="true" placeholder="'. esc_html__( 'Comment', 'autoser' ) .'"></textarea></fieldset>',
                 'label_submit' 		=> esc_html__( 'Post Comment', 'autoser' ),
                 'comment_notes_before' => '',
                 'comment_notes_after' 	=> '',   
                 'class_submit'      	=> 'btn',            
				 'format'        		=> 'xhtml',
	        )
	    ?>
	    <?php comment_form($comment_args); ?>
	</div>
</div>	

<!-- #comments -->
