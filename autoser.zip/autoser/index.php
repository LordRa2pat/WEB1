<?php
/**
 * The main template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package autoser
 */

get_header(); ?>

<?php if(autoser_get_option('page_header')) { ?>
<div id="featured-title" class="clearfix featured-title-left">
    <div id="featured-title-inner" class="wprt-container clearfix">
        <div class="featured-title-inner-wrap">
            <div class="featured-title-heading-wrap">
                <h1 class="featured-title-heading"><?php if( is_home() && is_front_page() ) echo esc_html__('BLOG', 'autoser'); else echo get_the_title( get_option( 'page_for_posts' ) ); ?></h1>
            </div>
            
            <?php if(!is_front_page() && autoser_get_option('breadcrumb') && function_exists('bcn_display')){ ?>
            <div id="breadcrumbs">
                <div class="breadcrumbs-inner">
                    <div class="breadcrumb-trail">
                        <?php bcn_display(); ?>
                    </div>
                </div>
            </div>
            <?php } ?>
        </div>
    </div>
</div>
<?php } ?>

<?php $type = autoser_get_option('blog_layout'); ?>
<div id="main-content" class="site-main clearfix">
    <div id="content-wrap" class="wprt-container <?php echo esc_attr($type); ?>">
        <div id="site-content" class="site-content clearfix">
            <div id="inner-content" class="inner-content-wrap">
                <?php if( have_posts() ) : ?>
                    <?php 
                        while (have_posts()) : the_post();
                            get_template_part( 'post-formats/content', get_post_format() ) ;
                        endwhile;
                    ?>
                <?php endif; ?>
                <div class="wprt-pagination clearfix">
                    <?php echo autoser_pagination(); ?> 
                </div>

            </div>
        </div>
        <?php if( $type != 'no-bar' ) { ?>
        <div id="sidebar">
            <div id="inner-sidebar" class="inner-content-wrap">
                <?php get_sidebar();?>
            </div>
        </div>
        <?php } ?>
    </div>
</div>
    
<?php get_footer(); ?>