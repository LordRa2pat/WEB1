<?php
/**
 * Icos theme customizer
 *
 * @package Icos
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Icos_Customize {
	/**
	 * Customize settings
	 *
	 * @var array
	 */
	protected $config = array();

	/**
	 * The class constructor
	 *
	 * @param array $config
	 */
	public function __construct( $config ) {
		$this->config = $config;

		if ( ! class_exists( 'Kirki' ) ) {
			return;
		}

		$this->register();
	}

	/**
	 * Register settings
	 */
	public function register() {
		/**
		 * Add the theme configuration
		 */
		if ( ! empty( $this->config['theme'] ) ) {
			Kirki::add_config(
				$this->config['theme'], array(
					'capability'  => 'edit_theme_options',
					'option_type' => 'theme_mod',
				)
			);
		}

		/**
		 * Add panels
		 */
		if ( ! empty( $this->config['panels'] ) ) {
			foreach ( $this->config['panels'] as $panel => $settings ) {
				Kirki::add_panel( $panel, $settings );
			}
		}

		/**
		 * Add sections
		 */
		if ( ! empty( $this->config['sections'] ) ) {
			foreach ( $this->config['sections'] as $section => $settings ) {
				Kirki::add_section( $section, $settings );
			}
		}

		/**
		 * Add fields
		 */
		if ( ! empty( $this->config['theme'] ) && ! empty( $this->config['fields'] ) ) {
			foreach ( $this->config['fields'] as $name => $settings ) {
				if ( ! isset( $settings['settings'] ) ) {
					$settings['settings'] = $name;
				}

				Kirki::add_field( $this->config['theme'], $settings );
			}
		}
	}

	/**
	 * Get config ID
	 *
	 * @return string
	 */
	public function get_theme() {
		return $this->config['theme'];
	}

	/**
	 * Get customize setting value
	 *
	 * @param string $name
	 *
	 * @return bool|string
	 */
	public function get_option( $name ) {
		if ( ! isset( $this->config['fields'][$name] ) ) {
			return false;
		}

		$default = isset( $this->config['fields'][$name]['default'] ) ? $this->config['fields'][$name]['default'] : false;

		return get_theme_mod( $name, $default );
	}
	public function get_option_default( $name ) {
		if ( ! isset( $this->config['fields'][ $name ] ) ) {
			return false;
		}

		return isset( $this->config['fields'][ $name ]['default'] ) ? $this->config['fields'][ $name ]['default'] : false;
	}
}

/**
 * This is a short hand function for getting setting value from customizer
 *
 * @param string $name
 *
 * @return bool|string
 */
function autoser_get_option( $name ) {
	global $autoser_customize;

	if ( empty( $autoser_customize ) ) {
		return false;
	}

	if ( class_exists( 'Kirki' ) ) {
		$value = Kirki::get_option( $autoser_customize->get_theme(), $name );
	} else {
		$value = $autoser_customize->get_option( $name );
	}

	return apply_filters( 'autoser_get_option', $value, $name );
}

/**
 * Get default option values
 *
 * @param $name
 *
 * @return mixed
 */
function autoser_get_option_default( $name ) {
	global $autoser_customize;

	if ( empty( $autoser_customize ) ) {
		return false;
	}

	return $autoser_customize->get_option_default( $name );
}

/**
 * Move some default sections to `general` panel that registered by theme
 *
 * @param object $wp_customize
 */
function autoser_customize_modify( $wp_customize ) {
	$wp_customize->get_section( 'title_tagline' )->panel     = 'general';
	$wp_customize->get_section( 'static_front_page' )->panel = 'general';
}

add_action( 'customize_register', 'autoser_customize_modify' );

/**
 * Customizer configuration
 */
$autoser_customize = new Icos_Customize(
	array(
		'theme'    => 'autoser',

		'panels'   => array(
			'general' => array(
				'priority' => 10,
				'title'    => esc_html__( 'General', 'autoser' ),
			),
			'header'  => array(
				'priority' => 110,
				'title'    => esc_html__( 'Header', 'autoser' ),
			),
			'footer'  => array(
				'priority' => 110,
				'title'    => esc_html__( 'Footer', 'autoser' ),
			),
		),

		'sections' => array(

			// Panel Header
			'topbar'     => array(
				'title'       => esc_html__( 'Top Bar', 'autoser' ),
				'description' => '',
				'priority'    => 10,
				'capability'  => 'edit_theme_options',
				'panel'       => 'header',
			),
			'logo'        => array(
				'title'       => esc_html__( 'Site Logo', 'autoser' ),
				'description' => '',
				'priority'    => 10,
				'capability'  => 'edit_theme_options',
				'panel'       => 'header',
			),
			'topmenu'     => array(
				'title'       => esc_html__( 'Navigation', 'autoser' ),
				'description' => '',
				'priority'    => 10,
				'capability'  => 'edit_theme_options',
				'panel'       => 'header',
			),
			'page_header' => array(
				'title'       => esc_html__( 'Page Header', 'autoser' ),
				'description' => '',
				'priority'    => 10,
				'capability'  => 'edit_theme_options',
				'panel'       => 'header',
			),
			
			// Panel Content
			'content'     => array(
				'title'       => esc_html__( 'Blog', 'autoser' ),
				'description' => '',
				'priority'    => 110,
				'capability'  => 'edit_theme_options',
			),

			// Panel 404
			'page404'     => array(
				'title'       => esc_html__( '404 Error', 'autoser' ),
				'description' => '',
				'priority'    => 110,
				'capability'  => 'edit_theme_options',
			),

			// Panel Footer
			'fwidgets'     => array(
				'title'       => esc_html__( 'Widgets', 'autoser' ),
				'description' => '',
				'priority'    => 120,
				'capability'  => 'edit_theme_options',
				'panel'       => 'footer',
			),
			'fbottom'     => array(
				'title'       => esc_html__( 'Copyright', 'autoser' ),
				'description' => '',
				'priority'    => 120,
				'capability'  => 'edit_theme_options',
				'panel'       => 'footer',
			),

			//Typography
			'typography'   => array(
				'priority'    => 120,
				'title'       => esc_html__( 'Typography', 'autoser' ),
				'capability'  => 'edit_theme_options',
			),

			// Panel Styling
			'styling'     => array(
				'title'       => esc_html__( 'Miscellaneous', 'autoser' ),
				'description' => '',
				'priority'    => 120,
				'capability'  => 'edit_theme_options',
			),

		),

		'fields'   => array(

			//Top Bar
			'tbar'       => array(
				'type'     => 'toggle',
				'label'    => esc_html__( 'Enable/Disable', 'autoser' ),
				'section'  => 'topbar',
				'default'  => '1',
				'priority' => 10,
			),
			'socials'      => array(
				'type'     => 'repeater',
				'label'    => esc_html__( 'Socials', 'autoser' ),
				'section'  => 'topbar',
				'priority' => 10,
				'default'  => array(),
				'row_label' => array(
					'type' => 'field',
					'value' => esc_attr__('Social', 'autoser' ),
					'field' => 'icon',
				),
				'fields'   => array(
					'icon' => array(
						'type'        => 'text',
						'label'       => esc_html__( 'Icon Class', 'autoser' ),
						'description' => esc_html__( 'This will be the social icon: https://fontawesome.com/v4.7.0/icons/', 'autoser' ),
						'default'     => '',
					),
					'link' => array(
						'type'        => 'text',
						'label'       => esc_html__( 'Social Link', 'autoser' ),
						'default'     => '',
					),
					'nwin'  => array(
						'type'        => 'checkbox',
						'label'       => esc_html__( 'Open In New Window', 'icos' ),
					),
				),
				'active_callback' => array(
				 	array(
					  	'setting'  => 'tbar',
					  	'operator' => '==',
					  	'value'    => 1,
				 	),
				),
			),
			'topinfo'      => array(
				'type'     => 'repeater',
				'label'    => esc_html__( 'Information', 'autoser' ),
				'section'  => 'topbar',
				'priority' => 10,
				'default'  => array(),
				'row_label' => array(
					'type' => 'field',
					'value' => esc_attr__('Info', 'autoser' ),
					'field' => 'text',
				),
				'fields'   => array(
					'icon' => array(
						'type'        => 'text',
						'label'       => esc_html__( 'Icon Class', 'autoser' ),
						'description' => esc_html__( 'Find icon: https://fontawesome.com/v4.7.0/icons/', 'autoser' ),
						'default'     => '',
					),
					'text' => array(
						'type'        => 'textarea',
						'label'       => esc_html__( 'Text', 'autoser' ),
						'default'     => '',
					),
				),
				'active_callback' => array(
				 	array(
					  	'setting'  => 'tbar',
					  	'operator' => '==',
					  	'value'    => 1,
				 	),
				),
			),
			'bg_top'    => array(
				'type'     => 'color',
				'label'    => esc_html__( 'Background', 'autoser' ),
				'section'  => 'topbar',
				'default'  => '',
				'priority' => 10,
				'output'    => array(
					array(
						'element'  => '#site-header-wrap #top-bar',
						'property' => 'background'
					),
				),
				'active_callback' => array(
				 	array(
					  	'setting'  => 'tbar',
					  	'operator' => '==',
					  	'value'    => 1,
				 	),
				),
			),
			'color_top'    => array(
				'type'     => 'color',
				'label'    => esc_html__( 'Text Color', 'autoser' ),
				'section'  => 'topbar',
				'default'  => '',
				'priority' => 10,
				'output'    => array(
					array(
						'element'  => '#site-header-wrap #top-bar, .header-style-2 #top-bar a',
						'property' => 'color'
					),
				),
				'active_callback' => array(
				 	array(
					  	'setting'  => 'tbar',
					  	'operator' => '==',
					  	'value'    => 1,
				 	),
				),
			),

			//Menu Top
			'header_style' => array(
				'type'     => 'select',
				'label'    => esc_html__( 'Header Style', 'icos' ),
				'section'  => 'topmenu',
				'default'  => 'dark',
				'priority' => 10,
				'choices'  => array(
					'h1' 	 => esc_html__( 'Default', 'icos' ),
					'h2' 	 => esc_html__( 'Two Rows', 'icos' ),
					'h3' 	 => esc_html__( 'Transparent', 'icos' ),
				),
			),
			'home_only'    => array(
				'type'     => 'toggle',
				'label'    => esc_html__( 'Home Only', 'autoser' ),
				'section'  => 'topmenu',
				'default'  => '1',
				'priority' => 10,
				'description' => esc_html__( 'Header transparent is only on homepage.', 'autoser' ),
				'active_callback' => array(
				 	array(
					  	'setting'  => 'header_style',
					  	'operator' => '==',
					  	'value'    => 'h3',
				 	),
				),
			),
			'sticky'       => array(
				'type'     => 'toggle',
				'label'    => esc_html__( 'Sticky Header', 'autoser' ),
				'section'  => 'topmenu',
				'default'  => '1',
				'priority' => 10,
			),
			'infos'      => array(
				'type'     => 'repeater',
				'label'    => esc_html__( 'Information', 'autoser' ),
				'section'  => 'topmenu',
				'priority' => 10,
				'default'  => array(),
				'row_label' => array(
					'type' => 'field',
					'value' => esc_attr__('Info', 'autoser' ),
					'field' => 'text',
				),
				'fields'   => array(
					'icon' => array(
						'type'        => 'text',
						'label'       => esc_html__( 'Icon Class', 'autoser' ),
						'description' => esc_html__( 'Find icon: https://fontawesome.com/v4.7.0/icons/', 'autoser' ),
						'default'     => '',
					),
					'text' => array(
						'type'        => 'textarea',
						'label'       => esc_html__( 'Text', 'autoser' ),
						'default'     => '',
					),
				),
				'active_callback' => array(
				 	array(
					  	'setting'  => 'header_style',
					  	'operator' => '==',
					  	'value'    => 'h2',
				 	),
				),
			),
			'btns'      => array(
				'type'     => 'repeater',
				'label'    => esc_html__( 'Buttons', 'autoser' ),
				'section'  => 'topmenu',
				'priority' => 10,
				'default'  => array(),
				'row_label' => array(
					'type' => 'field',
					'value' => esc_attr__('Button', 'autoser' ),
					'field' => 'label',
				),
				'fields'   => array(
					'label' => array(
						'type'        => 'text',
						'label'       => esc_html__( 'Label', 'autoser' ),
						'default'     => '',
					),
					'link' => array(
						'type'        => 'textarea',
						'label'       => esc_html__( 'Link', 'autoser' ),
						'default'     => '',
					),
					'target' => array(
						'type'        => 'checkbox',
						'label'       => esc_html__( 'Open in new window?', 'autoser' ),
						'default'     => 0,
					),
				),
				'active_callback' => array(
				 	array(
					  	'setting'  => 'header_style',
					  	'operator' => '==',
					  	'value'    => 'h2',
				 	),
				),
			),
			'search'      => array(
				'type'     => 'toggle',
				'label'    => esc_html__( 'Search Button', 'autoser' ),
				'section'  => 'topmenu',
				'default'  => '1',
				'priority' => 10,
			),
			'bg_menu'    => array(
				'type'     => 'color',
				'label'    => esc_html__( 'Background', 'autoser' ),
				'section'  => 'topmenu',
				'default'  => '',
				'priority' => 10,
				'output'    => array(
					array(
						'element'  => '.header-style-1 #site-header, #site-header .site-navigation-wrap',
						'property' => 'background'
					),
				),
			),
			'color_menu'    => array(
				'type'     => 'color',
				'label'    => esc_html__( 'Text Color', 'autoser' ),
				'section'  => 'topmenu',
				'default'  => '',
				'priority' => 10,
				'output'    => array(
					array(
						'element'  => '#main-nav > ul > li > a, #main-nav > ul > li > a:hover, #site-header .header-search-icon, #site-header .header-search-icon:hover, #site-header .site-navigation-wrap #main-nav > ul > li > a, #site-header .site-navigation-wrap .header-search-icon, #site-header .site-navigation-wrap .nav-cart-trigger',
						'property' => 'color'
					),
					array(
						'element'  => '.mobile-button:before, .mobile-button:after, .mobile-button span',
						'property' => 'background'
					),
				),
			),		
			'bg_smenu'    => array(
				'type'     => 'color',
				'label'    => esc_html__( 'Background Dropdown Menu', 'autoser' ),
				'section'  => 'topmenu',
				'default'  => '',
				'priority' => 10,
				'output'    => array(
					array(
						'element'  => '#main-nav .sub-menu, #main-nav .sub-menu .sub-menu',
						'property' => 'background'
					),
				),
			),
			'color_smenu'    => array(
				'type'     => 'color',
				'label'    => esc_html__( 'Text Color Dropdown Menu', 'autoser' ),
				'section'  => 'topmenu',
				'default'  => '',
				'priority' => 10,
				'output'    => array(
					array(
						'element'  => '#main-nav .sub-menu li a, #main-nav .sub-menu li a:hover',
						'property' => 'color'
					),
				),
			),
			'bg_mmenu'    => array(
				'type'     => 'color',
				'label'    => esc_html__( 'Background Mobile Menu', 'autoser' ),
				'section'  => 'topmenu',
				'default'  => '',
				'priority' => 10,
				'output'    => array(
					array(
						'element'  => '#main-nav-mobi, #main-nav-mobi ul ul li, #main-nav-mobi ul ul ul li',
						'property' => 'background'
					),
				),
			),
			'color_mmenu'    => array(
				'type'     => 'color',
				'label'    => esc_html__( 'Text Color Mobile Menu', 'autoser' ),
				'section'  => 'topmenu',
				'default'  => '',
				'priority' => 10,
				'output'    => array(
					array(
						'element'  => '#main-nav-mobi ul > li > a, #main-nav-mobi .menu-item-has-children .arrow:before',
						'property' => 'color'
					),
				),
			),

			// Logo
			'logo'         => array(
				'type'     => 'image',
				'label'    => esc_html__( 'Logo Image', 'autoser' ),
				'section'  => 'logo',
				'default'  => get_template_directory_uri() . '/assets/images/logo.png',
				'priority' => 10,
			),
			'logo_width'     => array(
				'type'     => 'number',
				'label'    => esc_html__( 'Logo Width', 'autoser' ),
				'section'  => 'logo',
				'priority' => 10,
				'output'    => array(
					array(
						'element'  => '#site-logo-inner img',
						'property' => 'width',
						'units'	   => 'px'
					),
				),
			),
			'logo_height'    => array(
				'type'     => 'number',
				'label'    => esc_html__( 'Logo Height', 'autoser' ),
				'section'  => 'logo',
				'priority' => 10,
				'output'    => array(
					array(
						'element'  => '#site-logo-inner img',
						'property' => 'height',
						'units'	   => 'px'
					),
				),
			),
			'logo_position'  => array(
				'type'     => 'spacing',
				'label'    => esc_html__( 'Logo Margin', 'autoser' ),
				'description' => esc_html__( 'Units: px. Example: 20px.', 'autoser' ),
				'section'  => 'logo',
				'priority' => 10,
				'default'  => array(
					'top'    => '0',
					'bottom' => '0',
					'left'   => '0',
					'right'  => '0',
				),
				'output'    => array(
					array(
						'element'  => '#site-logo-inner',
						'property' => 'margin',
					),
				),
			),

			// Page Header
			'page_header'    => array(
				'type'        => 'toggle',
				'label'       => esc_html__( 'Enable/Disable', 'autoser' ),
				'description' => esc_html__( 'Enable to show page header on whole site', 'autoser' ),
				'section'     => 'page_header',
				'default'     => '1',
				'priority'    => 10,
			),
			'breadcrumb'    => array(
				'type'        => 'toggle',
				'label'       => esc_html__( 'Breadcrumb', 'autoser' ),
				'description' => esc_html__( 'Enable to show breadcrumb on whole site', 'autoser' ),
				'section'     => 'page_header',
				'default'     => '1',
				'priority'    => 10,
				'active_callback' => array(
				 	array(
					  	'setting'  => 'page_header',
					  	'operator' => '==',
					  	'value'    => 1,
				 	),
				),
			),
			'head_height'  => array(
				'type'     => 'number',
				'label'    => esc_html__( 'Page Heading Height', 'autoser' ),
				'section'  => 'page_header',
				'default'  => '90',
				'priority' => 10,
				'active_callback' => array(
				 	array(
					  	'setting'  => 'page_header',
					  	'operator' => '==',
					  	'value'    => 1,
				 	),
				),
				'output'   => array(
					array(
						'element'  => '#featured-title .featured-title-inner-wrap',
						'property' => 'min-height',
						'units'	   => 'px'
					),
				),
			),
			'padd_top'  => array(
				'type'     => 'number',
				'label'    => esc_html__( 'Padding Top', 'autoser' ),
				'section'  => 'page_header',
				'default'  => '30',
				'priority' => 10,
				'active_callback' => array(
				 	array(
					  	'setting'  => 'page_header',
					  	'operator' => '==',
					  	'value'    => 1,
				 	),
				),
				'output'   => array(
					array(
						'element'  => '#featured-title .featured-title-inner-wrap',
						'property' => 'padding-top',
						'units'	   => 'px'
					),
				),
			),
			'page_bg_img'    => array(
				'type'     => 'image',
				'label'    => esc_html__( 'Background Image', 'autoser' ),
				'section'  => 'page_header',
				'default'  => '',
				'priority' => 10,
				'output'    => array(
					array(
						'element'  => '#featured-title',
						'property' => 'background-image'
					),
				),
				'active_callback' => array(
				 	array(
					  	'setting'  => 'page_header',
					  	'operator' => '==',
					  	'value'    => 1,
				 	),
				),
			),
			'page_bg_color'    => array(
				'type'     => 'color',
				'label'    => esc_html__( 'Background Color', 'autoser' ),
				'section'  => 'page_header',
				'default'  => '',
				'priority' => 10,
				'active_callback' => array(
				 	array(
					  	'setting'  => 'page_header',
					  	'operator' => '==',
					  	'value'    => 1,
				 	),
				),
				'output'    => array(
					array(
						'element'  => '#featured-title',
						'property' => 'background-color'
					),
				),
			),
			'page_header_color'    => array(
				'type'     => 'color',
				'label'    => esc_html__( 'Color Heading', 'autoser' ),
				'section'  => 'page_header',
				'default'  => '',
				'priority' => 10,
				'active_callback' => array(
				 	array(
					  	'setting'  => 'page_header',
					  	'operator' => '==',
					  	'value'    => 1,
				 	),
				),
				'output'    => array(
					array(
						'element'  => '#featured-title .featured-title-heading, #featured-title #breadcrumbs, #featured-title #breadcrumbs a',
						'property' => 'color'
					),
				),
			),
			'head_size'  => array(
				'type'     => 'number',
				'label'    => esc_html__( 'Heading Font Size', 'autoser' ),
				'section'  => 'page_header',
				'default'  => '18',
				'priority' => 10,
				'active_callback' => array(
				 	array(
					  	'setting'  => 'page_header',
					  	'operator' => '==',
					  	'value'    => 1,
				 	),
				),
				'output'   => array(
					array(
						'element'  => '#featured-title .featured-title-heading',
						'property' => 'font-size',
						'units'	   => 'px'
					),
				),
			),

			// Content
			'blog_layout'  => array(
				'type'     => 'radio-image',
				'label'    => esc_html__( 'Blog List Layout', 'autoser' ),
				'section'  => 'content',
				'default'  => 'default',
				'priority' => 10,
				'choices'  => array(
					'default' 	=> get_template_directory_uri() . '/framework/admin/images/right.png',
					'left-bar' 	=> get_template_directory_uri() . '/framework/admin/images/left.png',
					'no-bar' 	=> get_template_directory_uri() . '/framework/admin/images/full.png',
				),
			),
			'post_layout'  => array(
				'type'     => 'radio-image',
				'label'    => esc_html__( 'Single Blog Layout', 'autoser' ),
				'section'  => 'content',
				'default'  => 'default',
				'priority' => 10,
				'choices'  => array(
					'default' 	=> get_template_directory_uri() . '/framework/admin/images/right.png',
					'left-bar' 	=> get_template_directory_uri() . '/framework/admin/images/left.png',
					'no-bar' 	=> get_template_directory_uri() . '/framework/admin/images/full.png',
				),
			),
			'excerpt_length' => array(
				'type'     => 'number',
				'label'    => esc_html__( 'Excerpt Length', 'autoser' ),
				'section'  => 'content',
				'default'  => 60,
				'priority' => 12,
				'choices'  => array(
					'min'  => 0,
					'max'  => 100,
					'step' => 1,
				),
			),
			'readmore_btn' => array(
				'type'    		=> 'text',
				'label'   		=> esc_html__( 'Label Read More Button', 'autoser' ),
				'section' 		=> 'content',
				'default' 		=> 'Read More',
				'priority'    	=> 12,
			),
			'title_single' => array(
				'type'    		=> 'text',
				'label'   		=> esc_html__( 'Single Heading', 'autoser' ),
				'section' 		=> 'content',
				'default' 		=> 'Single Blog',
				'priority'    	=> 12,
			),
			

			//Footer
			'widgets'     => array(
				'type'        => 'toggle',
				'label'       => esc_html__( 'Enable/Disable', 'autoser' ),
				'section'     => 'fwidgets',
				'default'     => '1',
				'priority'    => 10,
			),	
			'ptop_widget'  => array(
				'type'     => 'number',
				'label'    => esc_html__( 'Padding Top', 'autoser' ),
				'section'  => 'fwidgets',
				'priority' => 10,
				'output'   => array(
					array(
						'element'  => '#footer',
						'property' => 'padding-top',
						'units'	   => 'px'
					),
				),
			),
			'pbot_widget'  => array(
				'type'     => 'number',
				'label'    => esc_html__( 'Padding Bottom', 'autoser' ),
				'section'  => 'fwidgets',
				'priority' => 10,
				'output'   => array(
					array(
						'element'  => '#footer',
						'property' => 'padding-bottom',
						'units'	   => 'px'
					),
				),
			),
			'bg_widget'    => array(
				'type'     => 'color',
				'label'    => esc_html__( 'Background Color', 'autoser' ),
				'section'  => 'fwidgets',
				'priority' => 10,
				'output'   => array(
					array(
						'element'  => '#footer',
						'property' => 'background-color',
					),
				),
				'active_callback' => array(
				 	array(
					  	'setting'  => 'widgets',
					  	'operator' => '==',
					  	'value'    => 1,
				 	),
				),
			),
			'c_widget'   => array(
				'type'     => 'color',
				'label'    => esc_html__( 'Color Text Subscribe', 'autoser' ),
				'section'  => 'fwidgets',
				'priority' => 10,
				'output'   => array(
					array(
						'element'  => '#footer-widgets .widget, #footer-widgets .widget.widget_links ul li a, #footer-widgets .widget .widget-title, #footer-widgets .widget .socials a, #footer-widgets .widget ul.links li a, #footer-widgets .widget ul.info li .hl',
						'property' => 'color',
					),
				),
				'active_callback' => array(
				 	array(
					  	'setting'  => 'widgets',
					  	'operator' => '==',
					  	'value'    => 1,
				 	),
				),
			),

			//Copyright
			'copy_right'   => array(
				'type'     => 'textarea',
				'label'    => esc_html__( 'Copy Right Text', 'autoser' ),
				'section'  => 'fbottom',
				'default'  => '',
				'priority' => 10,
			),
			'ptop_footer'  => array(
				'type'     => 'number',
				'label'    => esc_html__( 'Padding Top', 'autoser' ),
				'section'  => 'fbottom',
				'priority' => 10,
				'output'    => array(
					array(
						'element'  => '#bottom .bottom-bar-inner-wrap',
						'property' => 'padding-top',
						'units'	   => 'px'
					),
				),
			),
			'pbot_footer'  => array(
				'type'     => 'number',
				'label'    => esc_html__( 'Padding Bottom', 'autoser' ),
				'section'  => 'fbottom',
				'priority' => 10,
				'output'    => array(
					array(
						'element'  => '#bottom .bottom-bar-inner-wrap',
						'property' => 'padding-bottom',
						'units'	   => 'px'
					),
				),
			),
			'bg_footer'    => array(
				'type'     => 'color',
				'label'    => esc_html__( 'Background Footer', 'autoser' ),
				'section'  => 'fbottom',
				'priority' => 10,
				'output'    => array(
					array(
						'element'  => '#bottom',
						'property' => 'background',
					),
				),
			),
			'color_footer' => array(
				'type'     => 'color',
				'label'    => esc_html__( 'Color Text Footer', 'autoser' ),
				'section'  => 'fbottom',
				'priority' => 10,
				'output'    => array(
					array(
						'element'  => '#bottom, #bottom ul.bottom-nav > li > a',
						'property' => 'color',
					),
				),
			),
			

			//Styling
			'preload'     => array(
				'type'        => 'toggle',
				'label'       => esc_html__( 'Preloader', 'autoser' ),
				'section'     => 'styling',
				'default'     => '1',
				'priority'    => 10,
			),
			'main_color'   => array(
				'type'     => 'color',
				'label'    => esc_html__( 'Primary Color', 'autoser' ),
				'section'  => 'styling',
				'default'  => '#1c63b8',
				'priority' => 10,
			),

			// Typography
			'body_typo'    => array(
				'type'     => 'typography',
				'label'    => esc_html__( 'Body', 'autoser' ),
				'section'  => 'typography',
				'priority' => 10,
				'default'  => array(
					'font-family'    => 'Poppins',
					'variant'        => 'regular',
					'font-size'      => '15px',
					'line-height'    => '1.86',
					'letter-spacing' => '0',
					'subsets'        => array( 'latin-ext' ),
					'color'          => '#fff',
					'text-transform' => 'none',
				),
			),
			'heading1_typo'                           => array(
				'type'     => 'typography',
				'label'    => esc_html__( 'Heading 1', 'autoser' ),
				'section'  => 'typography',
				'priority' => 10,
				'default'  => array(
					'font-family'    => 'Poppins',
					'variant'        => '600',
					'font-size'      => '36px',
					'line-height'    => '1.33',
					'letter-spacing' => '0',
					'subsets'        => array( 'latin-ext' ),
					'color'          => '#fff',
					'text-transform' => 'none',
				),
			),
			'heading2_typo'                           => array(
				'type'     => 'typography',
				'label'    => esc_html__( 'Heading 2', 'autoser' ),
				'section'  => 'typography',
				'priority' => 10,
				'default'  => array(
					'font-family'    => 'Poppins',
					'variant'        => '600',
					'font-size'      => '30px',
					'line-height'    => '1.33',
					'letter-spacing' => '0',
					'subsets'        => array( 'latin-ext' ),
					'color'          => '#fff',
					'text-transform' => 'none',
				),
			),
			'heading3_typo'                           => array(
				'type'     => 'typography',
				'label'    => esc_html__( 'Heading 3', 'autoser' ),
				'section'  => 'typography',
				'priority' => 10,
				'default'  => array(
					'font-family'    => 'Poppins',
					'variant'        => '600',
					'font-size'      => '24px',
					'line-height'    => '1.33',
					'letter-spacing' => '0',
					'subsets'        => array( 'latin-ext' ),
					'color'          => '#fff',
					'text-transform' => 'none',
				),
			),
			'heading4_typo'                           => array(
				'type'     => 'typography',
				'label'    => esc_html__( 'Heading 4', 'autoser' ),
				'section'  => 'typography',
				'priority' => 10,
				'default'  => array(
					'font-family'    => 'Poppins',
					'variant'        => '600',
					'font-size'      => '18px',
					'line-height'    => '1.33',
					'letter-spacing' => '0',
					'subsets'        => array( 'latin-ext' ),
					'color'          => '#fff',
					'text-transform' => 'none',
				),
			),
			'heading5_typo'                           => array(
				'type'     => 'typography',
				'label'    => esc_html__( 'Heading 5', 'autoser' ),
				'section'  => 'typography',
				'priority' => 10,
				'default'  => array(
					'font-family'    => 'Poppins',
					'variant'        => '600',
					'font-size'      => '16px',
					'line-height'    => '1.33',
					'letter-spacing' => '0',
					'subsets'        => array( 'latin-ext' ),
					'color'          => '#fff',
					'text-transform' => 'none',
				),
			),
			'heading6_typo'                           => array(
				'type'     => 'typography',
				'label'    => esc_html__( 'Heading 6', 'autoser' ),
				'section'  => 'typography',
				'priority' => 10,
				'default'  => array(
					'font-family'    => 'Poppins',
					'variant'        => '600',
					'font-size'      => '12px',
					'line-height'    => '1.33',
					'letter-spacing' => '0',
					'subsets'        => array( 'latin-ext' ),
					'color'          => '#fff',
					'text-transform' => 'none',
				),
			),
			'menu_typo'                               => array(
				'type'     => 'typography',
				'label'    => esc_html__( 'Menu', 'autoser' ),
				'section'  => 'typography',
				'priority' => 10,
				'default'  => array(
					'font-family'    => 'Poppins',
					'variant'        => '500',
					'subsets'        => array( 'latin-ext' ),
					'font-size'      => '13px',
					'text-transform' => 'none',
				),
			),
			
		),
	)
);