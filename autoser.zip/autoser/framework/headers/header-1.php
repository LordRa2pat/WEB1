<div id="header-style" class="header-style-1">
    <header id="site-header">
        <div id="site-header-inner" class="wprt-container">
            <div class="wrap-inner">
                <div id="site-logo" class="clearfix">
                    <h1 id="site-logo-inner">
                        <?php $logo = autoser_get_option( 'logo' ); ?>
                        <a class="main-logo" href="<?php echo esc_url( home_url('/') ); ?>">
                            <img src="<?php echo esc_url($logo); ?>" alt="<?php bloginfo(); ?>">
                        </a>
                    </h1>
                </div>

                <div class="mobile-button"><span></span></div>

                <nav id="main-nav" class="main-nav">
                    <?php
                        $primary = array(
                            'theme_location'  => 'primary',
                            'menu'            => '',
                            'container'       => '',
                            'container_class' => '',
                            'container_id'    => '',
                            'menu_class'      => 'menu',
                            'menu_id'         => 'menu-primary-menu',
                            'echo'            => true,
                            'before'          => '',
                            'after'           => '',
                            'link_before'     => '',
                            'link_after'      => '',
                            'depth'           => 0,
                        );
                        if ( has_nav_menu( 'primary' ) ) {
                            wp_nav_menu( $primary );
                        }
                    ?>
                </nav>
                <?php if( autoser_get_option( 'search' ) ) { ?>
                <div id="header-search">
                    <a class="header-search-icon" href="#"><span class="search-icon rt-icon-search2"></span></a>
                    <?php echo get_search_form(); ?>
                </div>
                <?php } ?>
            </div>
        </div>
    </header>
</div>