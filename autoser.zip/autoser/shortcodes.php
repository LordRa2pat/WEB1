<?php 

// Heading
add_shortcode('heading', 'heading_func');
function heading_func($atts, $content = null){
    extract(shortcode_atts(array(
        'title'     =>  '',
        'line'      =>  '',
        'tag'       =>  'h1',
        'color'     =>  '',
        'align'     =>  'center',
        'iclass'    =>  '',
    ), $atts));
        $color1 = (!empty($color) ? 'style=color:'.$color.'' : '');
        $content = wpb_js_remove_wpautop( $content, true );
    ob_start(); ?>

    <div class="wprt-headings style-1 clearfix text-<?php echo esc_attr($align.' '.$iclass); ?>">
        <<?php echo esc_attr($tag); ?> class="heading <?php echo esc_attr($iclass); ?>" <?php echo esc_attr($color1); ?>><?php echo wp_specialchars_decode($title); ?></<?php echo esc_attr($tag); ?>>
        <?php if($line){ ?>
            <div class="sep clearfix"></div>
        <?php } ?>

        <?php if($content){ ?>
            <div class="sub-heading clearfix"><?php echo wp_specialchars_decode($content); ?></div>
        <?php } ?>
    </div>
        
<?php
    return ob_get_clean();
}

// Button
add_shortcode('button', 'button_func');
function button_func($atts, $content = null){
    extract(shortcode_atts(array(
        'btn_text'  =>  '',
        'btn_link'  =>  '',
        'style'     =>  'accent',
        'type'      =>  'solid',
        'size'      =>  'medium',
        'align'     =>  'text-left',
        'color'     =>  '',
        'bg_color'  =>  '',
        'bo_color'  =>  '',
        'iclass'    =>  '',
    ), $atts));
        if( $align == 'text-left' ){ $align .= ' button-wrap'; }

        $class     = 'wprt-button ' .esc_attr($size).' '. esc_attr($style).' '. esc_attr($type).' '.esc_attr($iclass);
        $color1    = (!empty($color) ? 'color:'.$color.';' : '');
        $bg_color1 = (!empty($bg_color) ? 'background-color:'.$bg_color.';' : '');
        $bo_color1 = (!empty($bo_color) ? 'border-color:'.$bo_color.';' : '');  
    ob_start(); ?>

    <div class="<?php echo esc_attr($align); ?>">
        <a class="<?php echo esc_attr($class); ?>" href="<?php echo esc_url($btn_link); ?>" style="<?php echo esc_attr($bg_color1);echo esc_attr($bo_color1);echo esc_attr($color1); ?>">
            <span><?php echo wp_specialchars_decode($btn_text); ?></span>
        </a>
    </div>
        
<?php
    return ob_get_clean();
}

// Accordion
add_shortcode('otaccor', 'otaccor_func');
function otaccor_func($atts, $content = null){
    extract(shortcode_atts(array(
        'accordion' =>  '',
        'iclass'    =>  '',
    ), $atts));
    $accs = (array) vc_param_group_parse_atts( $accordion );    
    ob_start(); ?>

    <div class="wprt-accordions style-2 <?php echo esc_attr($iclass); ?>">
        <?php foreach ( $accs as $acc ) : if($acc) : 
            $acc['title'] = isset($acc['title']) ? $acc['title'] : '';
            $acc['des']   = isset($acc['des']) ? $acc['des'] : '';            
        ?>
        <div class="accordion-item no-icon <?php if($acc['open']) echo 'active'; ?>">
            <h3 class="accordion-heading">
                <span class="inner"><?php echo wp_specialchars_decode($acc['title']); ?></span>
            </h3>
            <div class="accordion-content">
                <?php echo wp_specialchars_decode($acc['des']); ?>
            </div>
        </div>
        <?php endif; endforeach; ?>
    </div>
        
<?php
    return ob_get_clean();
}

// Home Slider
add_shortcode('homeslider', 'homeslider_func');
function homeslider_func($atts, $content = null){
    extract(shortcode_atts(array(
        'imgslide'      =>  '',
        'slide'         =>  '',
        'iclass'        =>  '',
    ), $atts));
        $imgslides = (array) vc_param_group_parse_atts( $imgslide );
        $j =count($imgslides);
        $content = wpb_js_remove_wpautop( $content, true );
    ob_start(); ?>

    <div class="hero-section slideshow text-center <?php echo esc_attr($iclass); ?>" data-height="full" data-count="<?php echo esc_attr($j); ?>" data-image="<?php foreach ( $imgslides as $data ) { $img = wp_get_attachment_image_src($data['photo'],'full'); $img = $img[0]; if($img) echo esc_url($img).'|'; } ?>" data-effect="fade" data-overlay="" data-poverlay="">
        <div class="hero-content">
            <div class="wprt-fancy-text typed" data-fancy="<?php echo esc_attr($slide); ?>">
                <h2 class="heading text-white"><span class="text"></span></h2>
            </div>

            <div class="sub-heading font-size-18"><?php echo wp_specialchars_decode($content); ?></div>

        </div>
    </div>
        
<?php
    return ob_get_clean();
}

// Fun Fact
add_shortcode('facts', 'facts_func');
function facts_func($atts, $content = null){
    extract(shortcode_atts(array(
        'title'     =>  '',
        'number'    =>  '',
        'symbol'    =>  '',
        'icon'      =>  '',
        'style'     =>  'icon-top',
        'iclass'    =>  '',
    ), $atts));
        
    ob_start(); ?>

    <div class="wprt-counter <?php if( $style == 'icon-left' ) echo 'icon-left style-2'; else echo 'icon-top style-1'; ?> text-center <?php echo esc_attr($iclass); ?>">
        <div class="inner">
            <div class="icon-wrap">
                <div class="icon"><i class="<?php echo esc_attr($icon); ?>"></i></div>
            </div>

            <div class="text-wrap">
                <div class="number-wrap font-heading">
                    <span class="prefix"></span><span class="number accent" data-speed="3000" data-to="<?php echo esc_attr($number); ?>" data-inviewport="yes"><?php echo esc_attr($number); ?></span><span class="suffix"><?php echo esc_html($symbol); ?></span>
                </div>

                <div class="sep"></div>
                <h3 class="heading"><?php echo wp_specialchars_decode($title); ?></h3>
            </div>
        </div>
    </div>
        
<?php
    return ob_get_clean();
}


// Portfolio Filter
add_shortcode('portfoliof', 'portfoliof_func');
function portfoliof_func($atts, $content = null){
    extract(shortcode_atts(array(
        'all'       =>  '',
        'num'       =>  '-1',
        'col'       =>  '4',
        'filter'    =>  '', 
        'gap'       =>  '0',
        'popup'     =>  '',
        'iclass'    =>  '',
    ), $atts));
    
    ob_start(); ?>

    <div class="wprt-gallery-grid <?php echo esc_attr($iclass); ?>" data-column="<?php echo esc_attr($col); ?>" data-column2="<?php echo esc_attr($col); ?>" data-column3="2" data-column4="1" data-gaph="<?php echo esc_attr($gap); ?>" data-gapv="<?php echo esc_attr($gap); ?>">
        <?php if($filter) { ?>
        <div id="gallery-filter">
            <div class="inner">
                <?php if($all) { ?><div data-filter="*" class="cbp-filter-item"><span><?php echo esc_html($all); ?></span></div><?php } ?>
                <?php 
                    $categories = get_terms('categories');
                    foreach( (array)$categories as $categorie){
                        $cat_name = $categorie->name;
                        $cat_slug = $categorie->slug;
                ?>
                <div data-filter=".<?php echo esc_attr( $cat_slug ); ?>" class="cbp-filter-item"><span><?php echo esc_html( $cat_name ); ?></span></div>
                <?php } ?>
            </div>
        </div>
        <?php } ?>
        <div id="galleries" class="cbp">
            <?php 
                $args = array(   
                    'post_type' => 'portfolio',   
                    'posts_per_page' => $num,               
                );  
                $wp_query = new WP_Query($args);
                while ($wp_query -> have_posts()) : $wp_query -> the_post(); 
                $cates = get_the_terms(get_the_ID(),'categories');
                $cate_name ='';
                $cate_slug = '';
                foreach((array)$cates as $cate){
                    if(count($cates)>0){
                        $cate_slug .= $cate->slug .' ';     
                    } 
                }               
                $style = get_post_meta(get_the_ID(),'_cmb_hover', true);;
            ?>
            <div class="cbp-item <?php echo esc_attr($cate_slug); ?>">
                <div class="gallery-box">
                    <div class="inner">
                        <div class="hover-effect">
                            <a class="overlay" href="<?php the_permalink(); ?>"></a>
                            <div class="gallery-image">
                                <?php the_post_thumbnail(); ?>
                            </div>

                            <div class="text">
                                <?php if($popup) { ?>
                                <div class="icon">
                                    <a class="zoom-popup" href="<?php the_post_thumbnail_url(); ?>"><i class="rt-icon-zoom-in-2"></i></a>
                                </div>
                                <?php } ?>
                                <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endwhile; wp_reset_postdata(); ?>
        </div>
    </div>

<?php
    return ob_get_clean();
}

// Portfolio Slider
add_shortcode('portfolios', 'portfolios_func');
function portfolios_func($atts, $content = null){
    extract(shortcode_atts(array(
        'num'       =>  '8',
        'col'       =>  '4',
        'arr'       =>  '',
        'navpos'    =>  'mid',
        'gap'       =>  '0',
        'popup'     =>  '',
        'iclass'    =>  '',
    ), $atts));
    
    $nav = '';
    if( $navpos == 'mid' ){
        $nav = 'has-arrows arrow-center offsetcenter offset-v0';
    }else{
        $nav = 'has-arrows arrow-top arrow45';
    }

    ob_start(); ?>

    <div class="wprt-gallery <?php if($arr) echo esc_attr($nav).' '.esc_attr($iclass); ?>" data-auto="false" data-column="<?php echo esc_attr($col); ?>" data-column2="<?php if($col > 1 ) echo esc_attr($col - 1); else echo '1'; ?>" data-column3="1" data-column4="1" data-gap="<?php echo esc_attr($gap); ?>">
        <div class="owl-carousel owl-theme">
            <?php 
                $args = array(   
                    'post_type' => 'portfolio',   
                    'posts_per_page' => $num,               
                );  
                $wp_query = new WP_Query($args);
                while ($wp_query -> have_posts()) : $wp_query -> the_post(); 
                $cates = get_the_terms(get_the_ID(),'categories');
                $cate_name ='';
                $cate_slug = '';
                foreach((array)$cates as $cate){
                    if(count($cates)>0){
                        $cate_name .= $cate->name.'<span>, </span>' ;
                        $cate_slug .= $cate->slug .' ';     
                    } 
                }               
            ?>
            <div class="gallery-box">
                <div class="inner">
                    <div class="hover-effect">
                        <a class="overlay" href="<?php the_permalink(); ?>"></a>
                        <div class="gallery-image">
                            <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
                        </div>
                        <div class="text">
                            <?php if($popup) { ?>
                            <div class="icon">
                                <a class="zoom-popup" href="<?php the_post_thumbnail_url(); ?>"><i class="rt-icon-zoom-in-2"></i></a>
                            </div>
                            <?php } ?>
                            <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                        </div>
                    </div>
                </div>
            </div>
            <?php endwhile; wp_reset_postdata(); ?>
        </div>
    </div>

<?php
    return ob_get_clean();
}


// Icon Box
add_shortcode('feature', 'feature_func');
function feature_func($atts, $content = null){
    extract(shortcode_atts(array(
        'icon'      =>  '',
        'photo'     =>  '',
        'title'     =>  '', 
        'linkbox'   =>  '',
        'iclass'    =>  '',
        'type'      =>  'grey-outline',
        'style'     =>  'style-1',
    ), $atts));
        if($style=='style-3'){
            $st = 'icon-left w70 align-left rounded-100';
        }elseif ($style=='style-4') {
            $st = 'icon-left w85 align-left';
        }elseif ($style=='style-6') {
            $st = 'icon-top w75 align-left';
        }elseif ($style=='style-7') {
            $st = 'icon-left';
        }else{
            $st = 'icon-top outline-type align-center rounded-100 w100';
        }
        $url    = vc_build_link( $linkbox );
        $content = wpb_js_remove_wpautop( $content, true );
    ob_start(); ?>

    <?php if( $style=='style-6' ) echo '<div class="wprt-content-box style-3">'; ?>
    <div class="wprt-icon-box clearfix has-width <?php echo esc_attr($style).' '.esc_attr($st).' '.esc_attr($type).' '.esc_attr($iclass); ?>">
        <div class="icon-wrap">
            <?php if( $style=='style-7' ) { ?>
            <?php if ( $photo != '' ) { echo wp_get_attachment_image( $photo, 'full', '', array( "class" => "img-responsive" ) ); } ?>
            <?php }else{ ?>
            <i class="<?php echo esc_attr($icon); ?>"></i>
            <?php } ?>
        </div>
        <h3 class="heading"><?php echo wp_specialchars_decode($title); ?></h3>

        <div class="desc"><?php echo wp_specialchars_decode($content); ?></div>

        <div class="elm-btn">
            <?php if ( strlen( $linkbox ) > 0 && strlen( $url['url'] ) > 0 ) {
                echo '<a class="simple-link font-heading" href="' . esc_attr( $url['url'] ) . '" target="' . ( strlen( $url['target'] ) > 0 ? esc_attr( $url['target'] ) : '_self' ) . '">' . esc_attr( $url['title'] ) .'</a>';
            } ?>
        </div>
    </div>
    <?php if( $style=='style-6' ) echo '</div>'; ?>

<?php
    return ob_get_clean();
}


// Pricing Table
add_shortcode('otpricing', 'otpricing_func');
function otpricing_func($atts, $content = null){
    extract(shortcode_atts(array(
        'title'     =>  '',
        'price'     =>  '',
        'linkbox'   =>  '', 
        'fav'       =>  '', 
        'iclass'    =>  '', 
    ), $atts));
        $url     = vc_build_link( $linkbox );
        $exclass = '';
        if( $fav ) { $exclass = 'wprt-button accent'; }else{ $exclass = 'wprt-button outline accent'; }  
        $content = wpb_js_remove_wpautop( $content, true );
    ob_start(); ?>

    <div class="wprt-price-table style-1 <?php if(!$fav) echo 'head-dark top-25'; ?> has-shadow <?php echo esc_attr($iclass); ?>">
        <div class="price-table-name">
            <div class="title"><?php echo wp_specialchars_decode($title); ?></div>
        </div>

        <div class="price-table-price">
            <div class="price-wrap"><span class="figure"><?php echo wp_specialchars_decode($price); ?></span></div>
        </div>

        <div class="price-table-features">
            <?php echo wp_specialchars_decode($content); ?>
            <div class="price-table-button">
                <?php if ( strlen( $linkbox ) > 0 && strlen( $url['url'] ) > 0 ) {
                    echo '<a class="'.$exclass.'" href="' . esc_attr( $url['url'] ) . '" target="' . ( strlen( $url['target'] ) > 0 ? esc_attr( $url['target'] ) : '_self' ) . '">' . esc_attr( $url['title'] ) .'</a>';
                } ?>
            </div>
        </div>
    </div>

<?php
    return ob_get_clean();
}

// Call To Action
add_shortcode('call_to', 'call_to_func');
function call_to_func($atts, $content = null){
    extract(shortcode_atts(array(
        'title'     =>  '',
        'linkbox'   =>  '',
        'iclass'    =>  '',
        'icon'      =>  '',
    ), $atts));
        $url    = vc_build_link( $linkbox );        
    ob_start(); ?>

    <div class="wprt-action-box style-1 has-icon <?php echo esc_attr($iclass); ?>">
        <div class="inner">
            <div class="heading-wrap">
                <div class="text-wrap">
                    <h3 class="heading"><?php echo wp_specialchars_decode($title); ?></h3>
                    <span class="icon"><i class="<?php echo esc_attr($icon); ?>"></i></span> 
                </div>
            </div>
            <div class="button-wrap">
                <?php if ( strlen( $linkbox ) > 0 && strlen( $url['url'] ) > 0 ) {
                    echo '<a class="wprt-button white rounded-3px" href="' . esc_attr( $url['url'] ) . '" target="' . ( strlen( $url['target'] ) > 0 ? esc_attr( $url['target'] ) : '_self' ) . '">' . esc_attr( $url['title'] ) .'</a>';
                } ?>
            </div>
        </div>
    </div>

<?php
    return ob_get_clean();
}

// Testimonial Silder
add_shortcode('testslide','testslide_func');
function testslide_func($atts, $content = null){
    extract(shortcode_atts(array(
        'testi'     =>  '',
        'col'       =>  '1',
        'nav'       =>  '',
        'navpos'    =>  'mid',
        'bul'       =>  '',
        'style'     =>  'style-1',
        'iclass'    =>  '',
    ), $atts));

    $test = (array) vc_param_group_parse_atts( $testi );    
    if( $navpos == 'mid' ){
        $nav = 'has-arrows arrow-center offsetcenter offset-v0 ';
    }else{
        $nav = 'has-arrows arrow-top arrow45 ';
    }
    ob_start(); 
?>

    <div class="wprt-carousel-box <?php if($bul) echo 'has-bullets bullet-circle '; if($nav) echo esc_attr($nav).esc_attr($iclass); ?>" data-auto="true" data-loop="false" data-gap="25" data-column="<?php echo esc_attr($col); ?>" data-column2="<?php if($col > 1 ) echo esc_attr($col - 1); else echo '1'; ?>" data-column3="1">
        <div class="owl-carousel owl-theme">
            <?php foreach ( $test as $tes ) { ?>
            <div class="wprt-testimonials <?php echo esc_attr($style); ?> clearfix image-circle">
                <div class="item">
                    <div class="inner">
                        <div class="thumb">
                            <?php if ( $tes['photo'] != '' ) { echo wp_get_attachment_image( $tes['photo'], 'full', '', array( "class" => "img-responsive" ) ); } ?>
                        </div>

                        <?php if( $style == 'style-2' ) { ?>
                            <h4 class="name">
                                <?php echo esc_html($tes['name']); ?><span class="company"><?php echo esc_html($tes['job']); ?></span>
                            </h4>
                            <blockquote class="text">
                                <p><?php echo wp_specialchars_decode($tes['text']); ?></p>
                            </blockquote>
                        <?php }else{ ?>
                            <blockquote class="text">
                                <p><?php echo wp_specialchars_decode($tes['text']); ?></p>
                                <div class="name-pos">
                                    <h6 class="name"><?php echo esc_html($tes['name']); ?></h6>
                                    <span class="position"><?php echo esc_html($tes['job']); ?></span>
                                </div>
                            </blockquote>
                        <?php } ?>
                    </div>
                </div>
            </div>
            <?php } ?>
        </div>
    </div>

<?php
    return ob_get_clean();
}



// Team Slider
add_shortcode('teamslider','teamslider_func');
function teamslider_func($atts, $content = null){
    extract(shortcode_atts(array(
        'num'       =>  '-1',
        'bul'       =>  '',
        'col'       =>  '4',
    ), $atts));
    
    ob_start(); 
?>  
    
    <div class="wprt-team <?php if($bul) echo 'has-shadow bullet-circle has-bullets'; ?>" data-auto="false" data-column="<?php echo esc_attr($col); ?>" data-column2="2" data-column3="1" data-gap="30">
        <div id="team-wrap" class="owl-carousel owl-theme">
            <?php           
                $args = array(
                    'post_type' => 'team',
                    'posts_per_page' => $num,
                );
                $team = new WP_Query($args);
                if($team->have_posts()) : while($team->have_posts()) : $team->the_post();
                $image = wp_get_attachment_url(get_post_thumbnail_id());
                $job = get_post_meta(get_the_ID(),'_cmb_job_team', true);
                $team_fb  = get_post_meta(get_the_ID(),'_cmb_team_fb', true);
                $team_tt  = get_post_meta(get_the_ID(),'_cmb_team_tt', true);
                $team_li  = get_post_meta(get_the_ID(),'_cmb_team_li', true);
                $team_gg  = get_post_meta(get_the_ID(),'_cmb_team_gg', true);
                $team_in  = get_post_meta(get_the_ID(),'_cmb_team_in', true);
                $link_soc = get_post_meta(get_the_ID(),'_cmb_link_soc', true);
                $icon_soc = get_post_meta(get_the_ID(),'_cmb_icon_soc', true);
            ?>

            <div class="team-item clearfix">
                <div class="inner">
                    <div class="thumb">
                        <?php the_post_thumbnail(); ?>
                        <ul class="socials clearfix">
                            <?php if($team_fb) { ?>
                                <li class="facebook"><a href="<?php echo esc_url($team_fb); ?>"><i class="fa fa-facebook"></i></a></li>
                            <?php }if($team_tt) { ?>                                    
                                <li class="twitter"><a href="<?php echo esc_url($team_tt); ?>"><i class="fa fa-twitter"></i></a></li>
                            <?php }if($team_li) { ?>
                                <li class="linkedin"><a href="<?php echo esc_url($team_li); ?>"><i class="fa fa-linkedin"></i></a></li>
                            <?php }if($team_gg) { ?>
                                <li class="google-plus"><a href="<?php echo esc_url($team_gg); ?>"><i class="fa fa-google-plus"></i></a></li>
                            <?php }if($team_in) { ?>
                                <li class="instagram"><a href="<?php echo esc_url($team_in); ?>"><i class="fa fa-instagram"></i></a></li>                               
                            <?php }if($link_soc && $icon_soc) { ?>
                                <li class="other-soc"><a href="<?php echo esc_url($link_soc); ?>"><i class="fa <?php echo esc_attr($icon_soc); ?>"></i></a></li>                               
                            <?php } ?>
                        </ul>
                    </div><!-- /.thumb -->

                    <div class="text-wrap">
                        <h4 class="name"><?php the_title(); ?></h4>
                        <div class="position"><?php echo esc_html($job); ?></div>
                    </div>
                </div>
            </div>

            <?php endwhile; wp_reset_postdata(); endif; ?>
        </div>
    </div>

<?php
    return ob_get_clean();
}


// Logo Clients
add_shortcode('clients','clients_func');
function clients_func($atts, $content = null){
    extract(shortcode_atts(array(
        'gallery'       =>  '',
        'col'           =>  '5',
        'bul'           =>  '',
        'bg'            =>  '',
        'style'         =>  'slider',
        'iclass'        =>  '',
    ), $atts));
    ob_start(); ?>

    <?php if( $style == 'grid' ) { ?>
    <div class="wprt-grid-box col-<?php echo esc_attr($col); ?>">
        <div class="grid-row clearfix">
            <?php 
                $img_ids = explode(",",$gallery);
                foreach( $img_ids AS $img_id ){
                $meta = wp_prepare_attachment_for_js($img_id);
                $link = $meta['caption'];
                $alt = $meta['alt'];
            ?>
            <div class="grid-item">
                <div class="wprt-adv-image clearfix">
                    <div class="inner">
                        <?php if($link) { ?><a target="_blank" href="<?php esc_url($link); ?>"><?php } ?>
                            <div class="thumb">
                                <?php if ( $img_id != '' ) { echo wp_get_attachment_image( $img_id, 'full', '', array( "class" => "img-responsive" ) ); } ?>
                            </div>
                        <?php if($link) { ?></a><?php } ?>
                    </div>
                </div>
            </div>
            <?php } ?>
        </div>
    </div>
    <?php }else{ ?>
    <div class="wprt-partner <?php if($bg) echo 'style-2'; else echo 'style-1'; ?> <?php if($bul) echo ' has-bullets bullet-circle bullet30'; echo esc_attr($iclass); ?>" data-auto="true" data-loop="true" data-column="<?php echo esc_attr($col); ?>" data-column2="3" data-column3="2" data-gap="20">
        <div class="owl-carousel owl-theme">
            <?php 
                $img_ids = explode(",",$gallery);
                foreach( $img_ids AS $img_id ){
                $meta = wp_prepare_attachment_for_js($img_id);
                $link = $meta['caption'];
                $alt  = $meta['alt'];
            ?>
            <div class="partner-item text-center clearfix">
                <div class="inner">
                    <?php if($link) { ?><a target="_blank" href="<?php esc_url($link); ?>"><?php } ?>
                        <div class="thumb">
                            <?php if ( $img_id != '' ) { echo wp_get_attachment_image( $img_id, 'full', '', array( "class" => "img-responsive" ) ); } ?>
                        </div>
                    <?php if($link) { ?></a><?php } ?>
                </div>
            </div>
            <?php } ?>
        </div>
    </div>
    <?php } ?>

<?php
    return ob_get_clean();  
}

// Service Box
add_shortcode('serbox', 'serbox_func');
function serbox_func($atts, $content = null){
    extract(shortcode_atts(array(
        'photo'     =>  '',
        'title'     =>  '',
        'iclass'    =>  '',
        'linkbox'   =>  ''
    ), $atts));
        $url    = vc_build_link( $linkbox );
        $content = wpb_js_remove_wpautop( $content, true );
    ob_start(); ?>

    <div class="wprt-image-box style-1 text-center clearfix <?php echo esc_attr($iclass); ?>">
        <div class="item">
            <div class="inner">
                <div class="thumb">
                    <?php if ( $photo != '' ) { echo wp_get_attachment_image( $photo, 'full', '', array( "class" => "img-responsive" ) ); } ?>
                </div>

                <div class="text-wrap">
                    <h3 class="title"><?php echo wp_specialchars_decode($title); ?></h3>

                    <div class="desc"><?php echo wp_specialchars_decode($content); ?></div>

                    <div class="elm-btn">
                        <?php if ( strlen( $linkbox ) > 0 && strlen( $url['url'] ) > 0 ) {
                            echo '<a class="small wprt-button accent" href="' . esc_attr( $url['url'] ) . '" target="' . ( strlen( $url['target'] ) > 0 ? esc_attr( $url['target'] ) : '_self' ) . '">' . esc_attr( $url['title'] ) .'</a>';
                        } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php
    return ob_get_clean();
}


// Image Carousel
add_shortcode('carousels','carousels_func');
function carousels_func($atts, $content = null){
    extract(shortcode_atts(array(
        'gallery'       =>  '',
        'col'           =>  '1',
        'gap'           =>  '30',
        'iclass'        =>  '',
    ), $atts));     
        
    ob_start(); ?>
    
    <div class="wprt-images-grid <?php echo esc_attr($iclass); ?>" data-layout="slider" data-column="<?php echo esc_attr($col); ?>" data-column2="<?php echo esc_attr($col); ?>" data-column3="<?php echo esc_attr($col); ?>" data-column4="<?php echo esc_attr($col); ?>" data-gaph="<?php echo esc_attr($gap); ?>" data-gapv="<?php echo esc_attr($gap); ?>">
        <div id="images-wrap" class="cbp">
            <?php 
                $img_ids = explode(",",$gallery);
                foreach( $img_ids AS $img_id ){
                $meta = wp_prepare_attachment_for_js($img_id);
                $alt = $meta['alt'];
            ?>
                <div class="cbp-item">
                    <div class="item-wrap">
                        <a class="zoom-popup" href="<?php echo esc_url($image_src[0]); ?>"><i class="rt-icon-zoom-in-2"></i></a>
                        <?php if ( $img_id != '' ) { echo wp_get_attachment_image( $img_id, 'full', '', array( "class" => "img-responsive" ) ); } ?>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>

<?php
    return ob_get_clean();  
}

// Image Carousel With Thumbnail
add_shortcode('carousel','carousel_func');
function carousel_func($atts, $content = null){
    extract(shortcode_atts(array(
        'gallery'   =>  '',
        'iclass'    =>  '',
    ), $atts));
        
    ob_start(); ?>
    
    <div class="wprt-thumb-slider <?php echo esc_attr($iclass); ?>" data-width="134.5" data-margin="14">
        <div id="wprt-slider" class="flexslider">
            <ul class="slides">
                <?php 
                    $img_ids = explode(",",$gallery);
                    foreach( $img_ids AS $img_id ){
                ?>
                    <li class="flex-active-slide">
                        <a class="zoom-popup" href="<?php echo esc_url($image_src[0]); ?>"><i class="rt-icon-zoom-in-2"></i></a>
                        <?php if ( $img_id != '' ) { echo wp_get_attachment_image( $img_id, 'full', '', array( "class" => "img-responsive" ) ); } ?>
                    </li>
                <?php } ?>                
            </ul>
        </div>

        <div id="wprt-carousel" class="flexslider">
            <ul class="slides">
                <?php 
                    $img_ids = explode(",",$gallery);
                    foreach( $img_ids AS $img_id ){
                ?>
                    <li><?php if ( $img_id != '' ) { echo wp_get_attachment_image( $img_id, 'full', '', array( "class" => "img-responsive" ) ); } ?></li>
                <?php } ?>
            </ul>
        </div>
    </div>  

<?php
    return ob_get_clean();  
}


//Skills
add_shortcode('skills','skills_func');
function skills_func($atts, $content = null){
    extract(shortcode_atts(array(
        'title'     =>  '',
        'number'    =>  '',
        'iclass'    =>  '',
    ), $atts));
    
    ob_start(); 
?>
    
    <div class="wprt-progress style-1 clearfix numb-grey height-4px <?php echo esc_attr($iclass); ?>">
        <h3 class="title"><?php echo wp_specialchars_decode($title) ?></h3>
        <div class="perc-wrap">
            <div class="perc"><span><?php echo esc_attr($number); ?>%</span></div>
        </div>
        <div class="progress-bg" data-percent="<?php echo esc_attr($number); ?>%" data-inviewport="yes">
            <div class="progress-animate"></div>
        </div>
    </div>

<?php
    return ob_get_clean();
}

// Contact Info
add_shortcode('cinfo', 'cinfo_func');
function cinfo_func($atts, $content = null){
    extract(shortcode_atts(array(
        'icon'      =>  '',
        'title'     =>  '',
        'iclass'    =>  '',
    ), $atts));
    $content = wpb_js_remove_wpautop( $content, true );
    ob_start(); ?>

    <div class="wprt-icon-box style-5 clearfix icon-left w50 accent-outline outline-type align-left rounded-100 has-width <?php echo esc_attr($iclass); ?>">
        <div class="icon-wrap">
            <i class="<?php echo esc_attr($icon); ?>"></i>
        </div>
        <h3 class="heading"><?php echo wp_specialchars_decode($title); ?></h3>
        <div class="desc"><?php echo wp_specialchars_decode($content); ?></div>
    </div>

<?php
    return ob_get_clean();
}