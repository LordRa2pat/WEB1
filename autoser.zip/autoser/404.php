<?php
/**
 * The template for displaying 404 pages (not found).
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package neovent
 */

wp_head(); ?>
  <div class="wrapper">
    <section class="no-padding">
      <div class="container">
        <div class="warp-404">
          <div class="warp-404-inner">
            <h1 class="id-color"><?php esc_html_e('404','neovent'); ?></h3>
            <h2><?php esc_html_e('Page Not Found','neovent'); ?></h2>
            <span><?php esc_html_e('The page you have requested cannot be found.','neovent'); ?></span>
            <p><?php wp_kses( _e('Maybe the page was moved or deleted, or perhaps you just mistyped the address.<br> Why not to try and find your way using the navigation bar above or click on the logo to return to our  home page.','neovent'), wp_kses_allowed_html('post') ); ?></p>
            <a href="<?php echo esc_url(home_url('/')); ?>" class="wprt-button medium accent solid"><?php esc_html_e('Back To Home','neovent'); ?></a>
          </div>
        </div>
      </div>
    </section>
  </div>
  
<?php wp_footer(); ?>