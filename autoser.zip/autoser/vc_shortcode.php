<?php 

// Heading
if(function_exists('vc_map')){
   vc_map( array(
   "name" => esc_html__("OT Heading", 'autoser'),
   "base" => "heading",
   "class" => "",
   "category" => 'Autoser Element',
   "icon" => "icon-st",
   "params" => array(
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Title", 'autoser'),
         "param_name" => "title",
         "value" => "",
         "description" => esc_html__("Title of heading", 'autoser')
      ),
      array(
         "type" => "dropdown",
         "holder" => "div",
         "heading" => esc_html__("Element Tag", 'autoser'),
         "param_name" => "tag",
         "value" => array(                        
                     esc_html__('h1', 'autoser')   => 'h1',
                     esc_html__('h2', 'autoser')   => 'h2',
                     esc_html__('h3', 'autoser')   => 'h3',
                     esc_html__('h4', 'autoser')   => 'h4',
                     esc_html__('h5', 'autoser')   => 'h5',
                     esc_html__('h6', 'autoser')   => 'h6',                     
                  ),
      ),
      array(
         "type" => "colorpicker",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Color", 'autoser'),
         "param_name" => "color",
         "value" => "",
         "description" => esc_html__("Color of title text", 'autoser')
      ),
      array(
         "type" => "dropdown",
         "holder" => "div",
         "heading" => esc_html__("Text Align", 'autoser'),
         "param_name" => "align",
         "value" => array(                        
                     esc_html__('Center', 'autoser')   => 'center',
                     esc_html__('Left', 'autoser')     => 'left',
                     esc_html__('Right', 'autoser')    => 'right',                   
                  ),
      ),      
      array(
         "type" => "checkbox",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Under Line", 'autoser'),
         "param_name" => "line",
         "value" => "",
      ),
      array(
         "type" => "textarea_html",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Subtitle", 'autoser'),
         "param_name" => "content",
         "value" => "",
         "description" => esc_html__("Subtitle of heading", 'autoser')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Extra Class", 'autoser'),
         "param_name" => "iclass",
         "value" => "",
      ),
    )));
}

// Button
if(function_exists('vc_map')){
   vc_map( array(
   "name" => esc_html__("OT Button", 'autoser'),
   "base" => "button",
   "class" => "",
   "category" => 'Autoser Element',
   "icon" => "icon-st",
   "params" => array(
      array(
         "type" => "textfield",
         "holder" => "div",
         "edit_field_class" => "vc_col-sm-6",
         "heading" => esc_html__("Button Text", 'autoser'),
         "param_name" => "btn_text",
         "value" => "",
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "edit_field_class" => "vc_col-sm-6",
         "heading" => esc_html__("Button Link", 'autoser'),
         "param_name" => "btn_link",
         "value" => "",
      ),
      array(
         "type" => "dropdown",
         "holder" => "div",
         "edit_field_class" => "vc_col-sm-6",
         "heading" => esc_html__("Size", 'autoser'),
         "param_name" => "size",
         "value" => array(                        
                     esc_html__('Normal', 'autoser')   => 'medium',
                     esc_html__('Small', 'autoser')    => 'small',
                     esc_html__('Big', 'autoser')      => 'big',                  
                  ),
      ),
      array(
         "type" => "dropdown",
         "holder" => "div",
         "edit_field_class" => "vc_col-sm-6",
         "heading" => esc_html__("Type", 'autoser'),
         "param_name" => "type",
         "value" => array(                        
                     esc_html__('Solid', 'autoser')     => 'solid',
                     esc_html__('Outline', 'autoser')   => 'outline',
                  ),
      ), 
      array(
         "type" => "dropdown",
         "holder" => "div",
         "edit_field_class" => "vc_col-sm-6",
         "heading" => esc_html__("Style", 'autoser'),
         "param_name" => "style",
         "value" => array(                        
                     esc_html__('Main Color', 'autoser') => 'accent',
                     esc_html__('Dark', 'autoser')       => 'dark',
                     esc_html__('Light', 'autoser')      => 'light',
                     esc_html__('Very Light', 'autoser') => 'very-light',
                  ),
      ), 
      array(
         "type" => "dropdown",
         "holder" => "div",
         "edit_field_class" => "vc_col-sm-6",
         "heading" => esc_html__("Align", 'autoser'),
         "param_name" => "align",
         "value" => array(                        
                     esc_html__('Left', 'autoser')     => 'text-left',
                     esc_html__('Center', 'autoser')   => 'text-center',
                     esc_html__('Right', 'autoser')    => 'text-right',
                  ),
      ), 
      array(
         "type" => "colorpicker",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Color Text", 'autoser'),
         "param_name" => "color",
         "value" => "",
      ),
      array(
         "type" => "colorpicker",
         "holder" => "div",
         "heading" => esc_html__("Backgound Color", 'autoser'),
         "param_name" => "bg_color",
         "value" => "",
         "dependency"  => array( 'element' => 'type', 'value' => 'solid' ),
      ), 
      array(
         "type" => "colorpicker",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Border Color", 'autoser'),
         "param_name" => "bo_color",
         "value" => "",
         "dependency"  => array( 'element' => 'type', 'value' => 'outline'),
      ), 
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Extra Class", 'autoser'),
         "param_name" => "iclass",
         "value" => "",
      ),    
    )));
}

// Accordion
if(function_exists('vc_map')){
   vc_map( array(
   "name" => esc_html__("OT Accordion", 'autoser'),
   "base" => "otaccor",
   "class" => "",
   "category" => 'Autoser Element',
   "icon" => "icon-st",
   "params" => array(
      array(
          'type' => 'param_group',
          'heading' => esc_html__("Accordion", 'autoser'),
          'value' => '',
          'param_name' => 'accordion',
          // Note params is mapped inside param-group:
          'params' => array(
               array(
                  "type" => "textfield",
                  "heading" => esc_html__("Title", 'autoser'),
                  "param_name" => "title",
                  "value" => "",
               ),
               array(
                  "type" => "textarea",
                  "heading" => esc_html__("Description", 'autoser'),
                  "param_name" => "des",
                  "value" => "",
               ),
               array(
                  "type" => "checkbox",
                  "heading" => esc_html__("Open?", 'autoser'),
                  "param_name" => "open",
                  "value" => "",
               ),
          )
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Extra Class", 'autoser'),
         "param_name" => "iclass",
         "value" => "",
      )
    )
   ));
}

// Hero Slider
if(function_exists('vc_map')){
   vc_map( array(
   "name" => esc_html__("OT Hero Slider", 'autoser'),
   "base" => "homeslider",
   "class" => "",
   "category" => 'Autoser Element',
   "icon" => "icon-st",
   "params" => array(
      array(
          'type' => 'param_group',
          'heading' => esc_html__("Slider Image", 'autoser'),
          'value' => '',
          'param_name' => 'imgslide',
          'params' => array(
               array(
                  'type' => 'attach_image',
                  'value' => '',
                  'heading' => 'Image',
                  'param_name' => 'photo',
               ),
          )
      ),
      array(
          'type' => 'textarea',
          'heading' => esc_html__("Slider Text", 'autoser'),
          'value' => '',
          'param_name' => 'slide',
      ),
      array(
         "type" => "textarea_html",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Small Text", 'autoser'),
         "param_name" => "content",
         "value" => "",
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Extra Class", 'autoser'),
         "param_name" => "iclass",
         "value" => "",
      ),
    )));
}


// Portfolio Filter
if(function_exists('vc_map')){
   vc_map( array(
   "name" => esc_html__("OT Portfolio Filter", 'autoser'),
   "base" => "portfoliof",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'Autoser Element',
   "params" => array( 
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Number Show", 'autoser'),
         "param_name" => "num",
      ),
      array(
         "type" => "dropdown",
         "holder" => "div",
         "edit_field_class" => "vc_col-sm-6",
         "heading" => esc_html__('Column', 'autoser'),
         "param_name" => "col",
         "value" => array(
                     esc_html__('4 Columns', 'autoser')     => '4', 
                     esc_html__('3 Columns', 'autoser')     => '3',
                     esc_html__('2 Columns', 'autoser')     => '2',
                  ), 
      ),
      array(
         "type" => "dropdown",
         "holder" => "div",
         "edit_field_class" => "vc_col-sm-6",
         "heading" => esc_html__('Gap', 'autoser'),
         "param_name" => "gap",
         "value" => array(
                     esc_html__('0px', 'autoser')     => '0', 
                     esc_html__('1px', 'autoser')     => '1',
                     esc_html__('2px', 'autoser')     => '2',
                     esc_html__('3px', 'autoser')     => '3',
                     esc_html__('4px', 'autoser')     => '4',
                     esc_html__('5px', 'autoser')     => '5',
                     esc_html__('10px', 'autoser')    => '10',
                     esc_html__('15px', 'autoser')    => '15',
                     esc_html__('20px', 'autoser')    => '20',
                     esc_html__('30px', 'autoser')    => '30',
                  ), 
      ),
       array(
         "type" => "checkbox",
         "holder" => "div",
         "edit_field_class" => "vc_col-sm-6",
         "class" => "",
         "heading" => esc_html__("Use Filter", 'autoser'),
         "param_name" => "filter",         
      ),
      array(
         "type" => "checkbox",
         "holder" => "div",
         "edit_field_class" => "vc_col-sm-6",
         "class" => "",
         "heading" => esc_html__("Popup Button", 'autoser'),
         "param_name" => "popup",         
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Show All Text", 'autoser'),
         "param_name" => "all",
         "dependency"  => array( 'element' => 'filter', 'value' => 'true' ),
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Extra Class", 'autoser'),
         "param_name" => "iclass",
         "value" => "",
      ),
    )));
}

// Portfolio Slider
if(function_exists('vc_map')){
   vc_map( array(
   "name" => esc_html__("OT Portfolio Slider", 'autoser'),
   "base" => "portfolios",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'Autoser Element',
   "params" => array( 
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Number Show", 'autoser'),
         "param_name" => "num",
      ),
      array(
         "type" => "dropdown",
         "holder" => "div",
         "edit_field_class" => "vc_col-sm-6",
         "heading" => esc_html__('Column', 'autoser'),
         "param_name" => "col",
         "value" => array(
                     esc_html__('4 Columns', 'autoser')     => '4', 
                     esc_html__('6 Columns', 'autoser')     => '6',
                     esc_html__('5 Columns', 'autoser')     => '5',
                     esc_html__('3 Columns', 'autoser')     => '3',
                     esc_html__('2 Columns', 'autoser')     => '2',
                     esc_html__('1 Columns', 'autoser')     => '1',
                  ), 
      ),
      array(
         "type" => "dropdown",
         "holder" => "div",
         "edit_field_class" => "vc_col-sm-6",
         "heading" => esc_html__('Gap', 'autoser'),
         "param_name" => "gap",
         "value" => array(
                     esc_html__('0px', 'autoser')     => '0', 
                     esc_html__('1px', 'autoser')     => '1',
                     esc_html__('2px', 'autoser')     => '2',
                     esc_html__('3px', 'autoser')     => '3',
                     esc_html__('4px', 'autoser')     => '4',
                     esc_html__('5px', 'autoser')     => '5',
                     esc_html__('10px', 'autoser')    => '10',
                     esc_html__('15px', 'autoser')    => '15',
                     esc_html__('20px', 'autoser')    => '20',
                     esc_html__('30px', 'autoser')    => '30',
                  ), 
      ),
      array(
         "type" => "checkbox",
         "holder" => "div",
         "edit_field_class" => "vc_col-sm-6",
         "class" => "",
         "heading" => esc_html__("Navigation", 'autoser'),
         "param_name" => "arr",
      ),
      array(
         "type" => "checkbox",
         "holder" => "div",
         "edit_field_class" => "vc_col-sm-6",
         "class" => "",
         "heading" => esc_html__("Popup Button", 'autoser'),
         "param_name" => "popup",         
      ),
      array(
         "type" => "dropdown",
         "heading" => esc_html__('Navigation Position', 'autoser'),
         "param_name" => "navpos",
         "value" => array(
                     esc_html__('Middle', 'autoser')     => 'mid', 
                     esc_html__('Top', 'autoser')        => 'top',
                  ), 
         "dependency"  => array( 'element' => 'arr', 'not_empty' => true ),
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Extra Class", 'autoser'),
         "param_name" => "iclass",
      ),
    )));
}


// Icon Box
if(function_exists('vc_map')){
   vc_map( array(
   "name" => esc_html__("OT Icon Box", 'autoser'),
   "base" => "feature",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'Autoser Element',
   "params" => array( 
      array(
         "type" => "dropdown",
         "holder" => "div",
         "edit_field_class" => "vc_col-sm-6",
         "class" => "",
         "heading" => esc_html__("Box Layout", 'autoser'),
         "param_name" => "style",
         "value" => array(                        
                     esc_html__('Icon Top Circle', 'autoser')     => 'style-1',
                     esc_html__('Icon Top Square', 'autoser')     => 'style-6',
                     esc_html__('Icon Left Circle', 'autoser')    => 'style-3',
                     esc_html__('Icon Left Square', 'autoser')    => 'style-4',
                     esc_html__('Image Left', 'autoser')          => 'style-7',
                  ),
      ),
      array(
         "type" => "dropdown",
         "holder" => "div",
         "edit_field_class" => "vc_col-sm-6",
         "class" => "",
         "heading" => esc_html__("Icon Style", 'autoser'),
         "param_name" => "type",
         "value" => array(                        
                     esc_html__('Icon With Border', 'autoser')     => 'grey-outline',
                     esc_html__('Icon With Backgound', 'autoser')  => 'accent-bg',
                  ),
      ),
      array(
         "type" => "iconpicker",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Icon", 'autoser'),
         "param_name" => "icon",
         "dependency"  => array( 'element' => 'style', 'value' => array('style-1','style-3','style-4', 'style-6') ),
      ),   
      array(
         "type" => "attach_image",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Image", 'autoser'),
         "param_name" => "photo",
         "dependency"  => array( 'element' => 'style', 'value' => 'style-7' ),
      ),       
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Title", 'autoser'),
         "param_name" => "title",
      ), 
      array(
         "type" => "textarea_html",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Content", 'autoser'),
         "param_name" => "content",
         "value" => "",
      ),
      array(
        'type' => 'vc_link',
         "heading" => esc_html__("Button", 'autoser'),
         "param_name" => "linkbox",         
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Extra Class", 'autoser'),
         "param_name" => "iclass",
      ), 
    )));
}

// Service Box
if(function_exists('vc_map')){
   vc_map( array(
   "name" => esc_html__("OT Service Box", 'autoser'),
   "base" => "serbox",
   "class" => "",
   "category" => 'Autoser Element',
   "icon" => "icon-st",
   "params" => array(  
      array(
          'type' => 'attach_image',
          'value' => '',
          'heading' => 'Image',
          'param_name' => 'photo',
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Title", 'autoser'),
         "param_name" => "title",
         "value" => "",
      ),
      array(
         "type" => "textarea_html",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Description", 'autoser'),
         "param_name" => "content",
         "value" => "",
      ),
      array(
         "type" => "vc_link",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Button", 'autoser'),
         "param_name" => "linkbox",
         "value" => "",
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Extra Class", 'autoser'),
         "param_name" => "iclass",
         "value" => "",
      ),
    )
   ));
}


// Pricing Table
if(function_exists('vc_map')){
   vc_map( array(
   "name" => esc_html__("OT Pricing Table", 'autoser'),
   "base" => "otpricing",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'Autoser Element',
   "params" => array(
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Title", 'autoser'),
         "param_name" => "title",
         "value" => "",
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Price", 'autoser'),
         "param_name" => "price",
         "value" => "",
      ),
      array(
         "type" => "textarea_html",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Content", 'autoser'),
         "param_name" => "content",
         "value" => "",
      ),
      array(
         "type" => 'vc_link',
         "heading" => esc_html__("Button", 'autoser'),
         "param_name" => "linkbox",         
      ),
      array(
         "type" => "checkbox",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Featured Table", 'autoser'),
         "param_name" => "fav",
         "value" => "",
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Extra Class", 'autoser'),
         "param_name" => "iclass",
         "value" => "",
      ),
    )));
}

// Call To Action
if(function_exists('vc_map')){
   vc_map( array(
   "name" => esc_html__("OT Call To Action", 'autoser'),
   "base" => "call_to",
   "class" => "",
   "category" => 'Autoser Element',
   "icon" => "icon-st",
   "params" => array(
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Title", 'autoser'),
         "param_name" => "title",
         "value" => "",
      ),
      array(
         "type" => "iconpicker",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Icon Left", 'autoser'),
         "param_name" => "icon",
         "value" => "",
      ),
      array(
        'type' => 'vc_link',
         "heading" => esc_html__("Button", 'autoser'),
         "param_name" => "linkbox",         
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Extra Class", 'autoser'),
         "param_name" => "iclass",
         "value" => "",
      ),
    )
   ));
}

// Fun Facts
if(function_exists('vc_map')){
   vc_map( array(
   "name" => esc_html__("OT Fun Facts", 'autoser'),
   "base" => "facts",
   "class" => "",
   "category" => 'Autoser Element',
   "icon" => "icon-st",
   "params" => array(
      array(
         "type" => "iconpicker",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Icon", 'autoser'),
         "param_name" => "icon",
         "value" => "",
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Title", 'autoser'),
         "param_name" => "title",
         "value" => "",
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "edit_field_class" => "vc_col-sm-6",
         "class" => "",
         "heading" => esc_html__("Number", 'autoser'),
         "param_name" => "number",
         "value" => "",
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "edit_field_class" => "vc_col-sm-6",
         "class" => "",
         "heading" => esc_html__("Extra Symbol", 'autoser'),
         "param_name" => "symbol",
         "description" => esc_html__("Ex: % or +", 'autoser'),
         "value" => "",
      ),
      array(
         "type" => "dropdown",
         "heading" => esc_html__('Style', 'autoser'),
         "param_name" => "style",
         "value" => array(
                     esc_html__('Icon Top', 'autoser')     => 'icon-top', 
                     esc_html__('Icon Left', 'autoser')    => 'icon-left',
                  ), 
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Extra Class", 'autoser'),
         "param_name" => "iclass",
         "value" => "",
      ),
    )));
}

// Testimonial Slider
if(function_exists('vc_map')){
   vc_map( array(
   "name" => esc_html__("OT Testimonials", 'autoser'),
   "base" => "testslide",
   "class" => "",
   "category" => 'Autoser Element',
   "icon" => "icon-st",
   "params" => array(
      array(
          'type' => 'param_group',
          'heading' => esc_html__("Testimonial", 'autoser'),
          'value' => '',
          'param_name' => 'testi',
          // Note params is mapped inside param-group:
          'params' => array(
               array(
                  'type' => 'attach_image',
                  'value' => '',
                  'heading' => 'Photo',
                  'param_name' => 'photo',
               ),
               array(
                  'type' => 'textfield',
                  'value' => '',
                  'heading' => esc_html__('Name', 'autoser'),
                  'param_name' => 'name',
               ),
               array(
                  'type' => 'textfield',
                  'value' => '',
                  'heading' => esc_html__('Job', 'autoser'),
                  'param_name' => 'job',
               ),
               array(
                  'type' => 'textarea',
                  'value' => '',
                  'heading' => esc_html__('Text', 'autoser'),
                  'param_name' => 'text',
               ),
          )
      ),
      array(
         "type" => "dropdown",
         "holder" => "div",
         "edit_field_class" => "vc_col-sm-6",
         "heading" => esc_html__('Style', 'autoser'),
         "param_name" => "style",
         "value" => array(
                     esc_html__('Top Photo', 'autoser')     => 'style-1', 
                     esc_html__('Bottom Photo', 'autoser')  => 'style-2',
                  ), 
      ),
      array(
         "type" => "dropdown",
         "holder" => "div",
         "edit_field_class" => "vc_col-sm-6",
         "heading" => esc_html__('Column', 'autoser'),
         "param_name" => "col",
         "value" => array(
                     esc_html__('1 Columns', 'autoser')     => '1', 
                     esc_html__('2 Columns', 'autoser')     => '2',
                     esc_html__('3 Columns', 'autoser')     => '3',
                  ), 
      ),
      array(
         "type" => "checkbox",
         "holder" => "div",
         "edit_field_class" => "vc_col-sm-6",
         "class" => "",
         "heading" => esc_html__("Arrows", 'autoser'),
         "param_name" => "nav",
      ),
      array(
         "type" => "checkbox",
         "holder" => "div",
         "edit_field_class" => "vc_col-sm-6",
         "class" => "",
         "heading" => esc_html__("Bullets", 'autoser'),
         "param_name" => "bul",
      ),
      array(
         "type" => "dropdown",
         "heading" => esc_html__('Navigation Position', 'autoser'),
         "param_name" => "navpos",
         "value" => array(
                     esc_html__('Middle', 'autoser')     => 'mid', 
                     esc_html__('Top', 'autoser')        => 'top',
                  ), 
         "dependency"  => array( 'element' => 'nav', 'not_empty' => true ),
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Extra Class", 'autoser'),
         "param_name" => "iclass",
         "value" => "",
      ),
    )));
}


// Team Slider
if(function_exists('vc_map')){
   vc_map( array(
   "name" => esc_html__("OT Team Slider", 'autoser'),
   "base" => "teamslider",
   "class" => "",
   "category" => 'Autoser Element',
   "icon" => "icon-st",
   "params" => array(
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Number Show", 'autoser'),
         "param_name" => "num",
      ),
      array(
         "type" => "dropdown",
         "heading" => esc_html__('Column', 'autoser'),
         "param_name" => "col",
         "value" => array(
                     esc_html__('4 Columns', 'autoser')     => '4', 
                     esc_html__('3 Columns', 'autoser')     => '3',
                     esc_html__('5 Columns', 'autoser')     => '5',
                  ), 
      ),
      array(
         "type" => "checkbox",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Pagination", 'autoser'),
         "param_name" => "bul",
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Extra Class", 'autoser'),
         "param_name" => "iclass",
         "value" => "",
      ),
    )));
}

// Logo Client
if(function_exists('vc_map')){
   vc_map( array(
   "name" => esc_html__("OT Client Logo", 'autoser'),
   "base" => "clients",
   "class" => "",
   "category" => 'Autoser Element',
   "icon" => "icon-st",
   "params" => array(
      array(
         "type" => "attach_images",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__('Images', 'autoser'),
         "param_name" => "gallery",
         "value" => "",
      ), 
      array(
         "type" => "dropdown",
         "holder" => "div",
         "edit_field_class" => "vc_col-sm-6",
         "heading" => esc_html__('Style', 'autoser'),
         "param_name" => "style",
         "value" => array(
                     esc_html__('Slider', 'autoser')   => 'slider', 
                     esc_html__('Grid', 'autoser')     => 'grid',
                  ), 
      ),
      array(
         "type" => "dropdown",
         "holder" => "div",
         "edit_field_class" => "vc_col-sm-6",
         "heading" => esc_html__('Column', 'autoser'),
         "param_name" => "col",
         "value" => array(
                     esc_html__('5 Columns', 'autoser')     => '5', 
                     esc_html__('3 Columns', 'autoser')     => '3',
                     esc_html__('4 Columns', 'autoser')     => '4',
                     esc_html__('6 Columns', 'autoser')     => '6',
                  ), 
      ),
      array(
         "type" => "checkbox",
         "holder" => "div",
         "edit_field_class" => "vc_col-sm-6",
         "class" => "",
         "heading" => esc_html__("Bullets", 'autoser'),
         "param_name" => "bul",
         "value" => "",
         "dependency"  => array( 'element' => 'style', 'value' => 'slider' ),
      ),
      array(
         "type" => "checkbox",
         "holder" => "div",
         "edit_field_class" => "vc_col-sm-6",
         "class" => "",
         "heading" => esc_html__("Gray Backgound", 'autoser'),
         "param_name" => "bg",
         "value" => "",
         "dependency"  => array( 'element' => 'style', 'value' => 'slider' ),
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Extra Class", 'autoser'),
         "param_name" => "iclass",
         "value" => "",
      ),   
    )
    ));
}


// Image Carousel
if(function_exists('vc_map')){
   vc_map( array(
   "name" => esc_html__("OT Image Carousel", 'autoser'),
   "base" => "carousels",
   "class" => "",
   "category" => 'Autoser Element',
   "icon" => "icon-st",
   "params" => array(
      array(
         "type" => "attach_images",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__('Images', 'autoser'),
         "param_name" => "gallery",
         "value" => "",         
      ),
      array(
         "type" => "dropdown",
         "heading" => esc_html__('Column', 'autoser'),
         "param_name" => "col",
         "value" => array(
                     esc_html__('1 Columns', 'autoser')     => '1', 
                     esc_html__('2 Columns', 'autoser')     => '2',
                     esc_html__('3 Columns', 'autoser')     => '3',
                     esc_html__('4 Columns', 'autoser')     => '4',
                  ), 
      ),
      array(
         "type" => "textfield",
         "heading" => esc_html__('Gap', 'autoser'),
         "param_name" => "gap",
         "value" => "",
      ),
      array(
         "type" => "checkbox",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Navigation", 'autoser'),
         "param_name" => "navi",
         "value" => "",
      ),
      array(
         "type" => "checkbox",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Pagination", 'autoser'),
         "param_name" => "pagi",
         "value" => "",
      ),  
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Extra Class", 'autoser'),
         "param_name" => "iclass",
         "value" => "",
      ),        
    )));
}

// Image Carousel With Thumbnail
if(function_exists('vc_map')){
   vc_map( array(
   "name" => esc_html__("OT Image Carousel With Thumnail", 'autoser'),
   "base" => "carousel",
   "class" => "",
   "category" => 'Autoser Element',
   "icon" => "icon-st",
   "params" => array(
      array(
         "type" => "attach_images",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__('Images', 'autoser'),
         "param_name" => "gallery",
         "value" => "",         
      ),  
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Extra Class", 'autoser'),
         "param_name" => "iclass",
         "value" => "",
      ),            
    )));
}


// Skills
if(function_exists('vc_map')){
   vc_map( array(
   "name" => esc_html__("OT Skills", 'autoser'),
   "base" => "skills",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'Autoser Element',
   "params" => array(
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Title", 'autoser'),
         "param_name" => "title",
         "value" => "",
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Number", 'autoser'),
         "param_name" => "number",
         "value" => "",
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Extra Class", 'autoser'),
         "param_name" => "iclass",
         "value" => "",
      ),
    )));
}

// Contact Info
if(function_exists('vc_map')){
   vc_map( array(
   "name" => esc_html__("OT Contact Info", 'autoser'),
   "base" => "cinfo",
   "class" => "",
   "category" => 'Autoser Element',
   "icon" => "icon-st",
   "params" => array(  
      array(
         "type" => "iconpicker",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Icon Left", 'autoser'),
         "param_name" => "icon",
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Title", 'autoser'),
         "param_name" => "title",
         "value" => "",
      ),
      array(
         "type" => "textarea_html",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Details", 'autoser'),
         "param_name" => "content",
         "value" => "",
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__("Extra Class", 'autoser'),
         "param_name" => "iclass",
         "value" => "",
      ),
    )
   ));
}