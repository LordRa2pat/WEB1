<?php 

//Custom Style Frontend
if(!function_exists('autoser_color_scheme')){
    function autoser_color_scheme(){
        $color_scheme = '';

        //Main Color
        if(autoser_get_option('main_color') != '#1c63b8'){
            $color_scheme = 
            '
			.wprt-button.accent,
			.wprt-button.outline.accent:hover,
			.wprt-button.dark:hover,
			.wprt-button.light:hover,
			.wprt-button.very-light:hover,
			.wprt-button.outline.dark:hover,
			.wprt-button.outline.light:hover,
			.wprt-button.outline.very-light:hover,
			.wprt-headings .sep,
			.wprt-counter .sep,
			.wprt-icon.style-3 .icon,
			.wprt-icon-box .elm-btn .simple-link2:after,.wprt-icon-box .elm-btn .simple-link:after,
			.wprt-icon-box.accent-bg .icon-wrap,
			.wprt-icon-box.grey-bg:hover .icon-wrap,
			.wprt-icon-box.grey-bg .icon-wrap:after,
			.wprt-icon-box.accent-outline:hover .icon-wrap,
			.wprt-icon-box.accent-outline .icon-wrap:after,
			.wprt-icon-box.grey-outline:hover .icon-wrap,
			.wprt-icon-box.grey-outline .icon-wrap:after,
			.wprt-thumb-slider #wprt-slider .flex-direction-nav a,
			.wprt-navbar .menu>li.current-nav-item,
			.wprt-image-box .item .simple-link:after,
			.wprt-news .news-item .meta,
			.wprt-news .news-item .simple-link:after,
			#gallery-filter .cbp-filter-item.cbp-filter-item-active:before,
			.gallery-box .hover-effect .icon>a,
			.wprt-tabs.style-2 .tab-title .item-title.active,
			.wprt-tabs.style-3 .tab-title .item-title.active,
			.wprt-lines .line-1,
			.wprt-images-grid .cbp-nav-next,.wprt-images-grid .cbp-nav-prev,
			.wprt-progress.numb-accent .perc>span,
			.wprt-progress.style-1 .progress-animate,
			.wprt-progress.style-2 .progress-animate,
			.wprt-accordions.style-1 .accordion-item.active .accordion-heading,
			.wprt-team .socials li a:hover,
			.wprt-price-table .price-table-price,
			.owl-theme .owl-nav [class*=owl-],
			.owl-theme .owl-dots .owl-dot.active span,
			blockquote:before,
			button:hover,input[type="button"]:hover,input[type="reset"]:hover,input[type="submit"]:hover,button:focus,input[type="button"]:focus,input[type="reset"]:focus,input[type="submit"]:focus,
			.bg-accent,
			#top-bar .top-bar-socials .icons a:hover,
			#top-bar.style-3,
			#site-header .site-navigation-wrap,
			.header-style-2 #site-header #main-nav > ul > li > a:hover:before,.header-style-2 #site-header #main-nav > ul > li.current-menu-item > a:before,
			.nav-top-cart-wrapper .shopping-cart-items-count,
			.nav-top-cart-wrapper .nav-shop-cart .buttons > a:first-child,
			#main-nav li.megamenu > ul.sub-menu > .menu-item-has-children > a:before,
			.post-media > .post-cat a,
			.hentry .post-link a,
			.hentry .post-tags a:hover,
			.comment-reply:after,
			#footer-widgets .widget .widget-title > span:after,
			.widget.widget_nav_menu .menu > li:before,
			.widget.widget_nav_menu .menu > li.current-menu-item > a,.widget.widget_nav_menu .menu > li.current-menu-item,
			#footer-widgets .widget.widget_nav_menu .menu > li.current-menu-item > a,#footer-widgets .widget.widget_nav_menu .menu > li.current-menu-item,
			#sidebar .widget.widget ul.info li .inner:before,#footer-widgets .widget ul.info li .inner:before,
			#footer-widgets .widget ul.links li a:before,
			#sidebar .widget .socials a:hover,#footer-widgets .widget .socials a:hover,#footer-widgets .widget .socials a.active,
			#footer-widgets .widget.widget_recent_posts .recent-news .thumb.icon,
			#sidebar .widget.widget_tag_cloud .tagcloud a:hover,#footer-widgets .widget.widget_tag_cloud .tagcloud a:hover,.widget_product_tag_cloud .tagcloud a:hover,
			#scroll-top:hover:before,
			.wprt-pagination ul li a.page-numbers:hover,.woocommerce-pagination .page-numbers li .page-numbers:hover,.wprt-pagination ul li .page-numbers.current,.woocommerce-pagination .page-numbers li .page-numbers.current,
			.widget.widget_nav_menu .menu > li.current-nav-item,
			.woocommerce-page .content-woocommerce .products li .onsale ,
			.woocommerce nav.woocommerce-pagination ul li a:focus, .woocommerce nav.woocommerce-pagination ul li a:hover, .woocommerce nav.woocommerce-pagination ul li span.current,
			.woocommerce-page .content-woocommerce .products li .added_to_cart.wc-forward ,
			.woocommerce-page .content-woocommerce .products li .add_to_cart_button.added ,
			.woocommerce-page .woo-single-post-class .summary .cart .single_add_to_cart_button ,
			.woocommerce-page .cart_totals .wc-proceed-to-checkout a ,
			.woocommerce-page #payment #place_order ,
			.woocommerce .widget_price_filter .ui-slider .ui-slider-range{background-color: '.autoser_get_option('main_color').';}

			/*Border Color*/ 

			.wprt-button.outline.accent, 
			.wprt-button.outline.dark:hover, 
			.wprt-button.outline.light:hover, 
			.wprt-button.outline.very-light:hover, 
			.wprt-icon.outline .icon, 
			.wprt-icon-box.accent-outline .icon-wrap, 
			.wprt-icon-box.grey-outline:hover .icon-wrap, 
			.wprt-thumb-slider #wprt-carousel .slides>li.flex-active-slide:after,.wprt-thumb-slider #wprt-carousel .slides>li:hover:after, 
			.wprt-navbar .menu>li.current-nav-item, 
			.divider-icon-after.accent,.divider-icon-before.accent,.wprt-divider.has-icon .divider-double.accent, 
			.wprt-images-grid .cbp-nav-pagination-active, 
			.wprt-accordions.style-2 .accordion-item.active .accordion-heading, 
			.owl-theme .owl-dots .owl-dot.active span, 
			.hentry .post-tags a:hover, 
			#sidebar .widget .socials a:hover,#footer-widgets .widget .socials a:hover,#footer-widgets .widget .socials a.active, 
			#sidebar .widget.widget_tag_cloud .tagcloud a:hover,#footer-widgets .widget.widget_tag_cloud .tagcloud a:hover,.widget_product_tag_cloud .tagcloud a:hover, 
			.wprt-pagination ul li a.page-numbers:hover,.woocommerce-pagination .page-numbers li .page-numbers:hover,.wprt-pagination ul li .page-numbers.current,.woocommerce-pagination .page-numbers li .page-numbers.current, 
			.widget.widget_nav_menu .menu > li.current-nav-item, 
			.wpb-js-composer div.vc_tta-color-grey.vc_tta-style-classic.vc_tta-tabs-position-top li.vc_tta-tab.vc_active>a, 
			.wpb-js-composer div.vc_tta-tabs:not([class*=vc_tta-gap]):not(.vc_tta-o-no-fill).vc_tta-tabs-position-top .vc_tta-tab.vc_active>a,
			.woocommerce-page .content-woocommerce .products li .product-thumbnail:hover, 
			.woocommerce-page .content-woocommerce .products li .product-thumbnail:after , 
			.woocommerce-page .content-woocommerce .products li .added_to_cart.wc-forward , 
			.woocommerce-page .content-woocommerce .products li .add_to_cart_button.added , 
			.woocommerce-page .woo-single-post-class .summary .cart .single_add_to_cart_button{border-color: '.autoser_get_option('main_color').';}
			
			/*Border Top*/ 

			.wprt-tabs.style-1 .tab-title .item-title.active>span, 
			.wprt-tabs.style-2 .tab-title .item-title.active>span, 
			.wprt-progress.numb-accent .perc>span:after{border-top-color: '.autoser_get_option('main_color').';}

			/*Border Left*/ 

			.wprt-tabs.style-4 .tab-title .item-title.active>span{border-left-color:'.autoser_get_option('main_color').';}

			/*Color*/ 

			.wprt-button.outline.accent, 
			.wprt-fancy-text.typed .heading, 
			.wprt-fancy-text.typed .typed-cursor, 
			.wprt-counter .prefix,.wprt-counter .suffix, 
			.wprt-counter.style-1 .number-wrap, 
			.wprt-counter.style-2 .icon, 
			.wprt-icon.outline .icon, 
			.wprt-icon.style-1 .icon, 
			.wprt-icon-box .heading a:hover,.wprt-icon-box.simple .icon-wrap, 
			.wprt-icon.style-5 .icon, 
			.wprt-icon-box.grey-bg .icon-wrap, 
			.wprt-icon-box.accent-outline .icon-wrap, 
			.wprt-icon-box.grey-outline .icon-wrap, 
			.wprt-navbar .menu>li>a:hover, 
			.wprt-image-box .item .title a:hover, 
			.wprt-news .news-item .text-wrap .title a:hover, 
			#gallery-filter .cbp-filter-item:hover, 
			#gallery-filter .cbp-filter-item.cbp-filter-item-active, 
			.wprt-list.style-1 .icon,ul.wprt-list.style-1 i, 
			.wprt-divider.has-icon .icon-wrap>span, 
			.wprt-accordions .accordion-item .accordion-heading:hover, 
			.wprt-accordions.style-2 .accordion-item.active .accordion-heading, 
			.wprt-accordions.style-2 .accordion-item.active .accordion-heading:after, 
			.wprt-accordions.style-2 .accordion-item .accordion-heading:hover, 
			.wprt-accordions.style-1 .accordion-item .accordion-heading:after, 
			a, 
			.text-accent-color, 
			.heading b, 
			.header-style-2 #top-bar .top-bar-socials .icons a:hover, 
			#site-logo .site-logo-text:hover, 
			#site-header .header-search-icon:hover, 
			.header-style-2 #site-header .header-search-icon:hover, 
			.nav-top-cart-wrapper .nav-shop-cart ul li a:hover, 
			.nav-top-cart-wrapper .nav-shop-cart ul li a.remove, 
			#site-header .header-info .info-c > .title, 
			#main-nav > ul > li > a:hover,#main-nav > ul > li.current-menu-item > a, 
			#main-nav-mobi ul > li > a:hover, 
			.hentry .post-title a:hover, 
			.hentry .post-meta a:hover, 
			.comment-author a:hover, 
			#sidebar .widget.widget_calendar caption,#footer-widgets .widget.widget_calendar caption, 
			.widget.widget_categories ul li a:hover,.widget.widget_meta ul li a:hover,.widget.widget_pages ul li a:hover,.widget.widget_archive ul li a:hover,.widget.widget_recent_entries ul li a:hover,.widget.widget_recent_comments ul li a:hover, .widget.widget_product_categories ul li a:hover,
			#footer-widgets .widget.widget_categories ul li a:hover,#footer-widgets .widget.widget_meta ul li a:hover,#footer-widgets .widget.widget_pages ul li a:hover,#footer-widgets .widget.widget_archive ul li a:hover,#footer-widgets .widget.widget_recent_entries ul li a:hover,#footer-widgets .widget.widget_recent_comments ul li a:hover, 
			#sidebar .widget.widget_recent_news h3 a:hover, 
			.widget.widget_nav_menu .menu > li > a:hover, 
			#footer-widgets .widget.widget_nav_menu .menu > li > a:hover, 
			#sidebar .widget.widget_calendar tbody #today,#sidebar .widget.widget_calendar tbody #today a, 
			#sidebar .widget.widget_links ul li a:hover,#footer-widgets .widget ul.links li a:hover, 
			#sidebar .widget.widget_recent_posts .recent-news .thumb.icon,#footer-widgets .widget.widget_recent_posts .recent-news .thumb.icon, 
			#sidebar .widget.widget_recent_posts h3 a:hover,#footer-widgets .widget.widget_recent_posts h3 a:hover, 
			.widget.widget_nav_menu .menu > li > a:hover,
			.woocommerce-page .content-woocommerce .products li h3:hover , 
			.woocommerce ul.products li.product .price , 
			.woocommerce-page .woo-single-post-class .summary .price{color: '.autoser_get_option('main_color').';}

			';
        }

        if(! empty($color_scheme)){
			echo '<style type="text/css">'.$color_scheme.'</style>';
		}
    }
}
add_action('wp_head', 'autoser_color_scheme');