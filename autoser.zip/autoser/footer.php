<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package autoser
 */
?>
        <?php if( autoser_get_option( 'widgets' ) ) { ?>
        <footer id="footer">
            <div id="footer-widgets" class="container">
                <div class="row">
                    <?php get_sidebar('footer') ?>
                </div>
            </div>
        </footer>
        <?php } ?>
        
        <?php if( autoser_get_option( 'copy_right' ) ) { ?>
        <div id="bottom" class="clearfix style-1">
            <div id="bottom-bar-inner" class="wprt-container">
                <div class="bottom-bar-inner-wrap">
                    <div class="bottom-bar-content">
                        <div id="copyright">
                            <?php echo wp_specialchars_decode(autoser_get_option( 'copy_right' )); ?>
                        </div>
                    </div>

                    <div class="bottom-bar-menu">
                        <?php
                            $footer = array(
                                'theme_location'  => 'footer',
                                'menu'            => '',
                                'container'       => '',
                                'container_class' => '',
                                'container_id'    => '',
                                'menu_class'      => 'bottom-nav',
                                'menu_id'         => '',
                                'echo'            => true,
                                'before'          => '',
                                'after'           => '',
                                'link_before'     => '',
                                'link_after'      => '',
                                'depth'           => 0,
                            );
                            if ( has_nav_menu( 'footer' ) ) {
                                wp_nav_menu( $footer );
                            }
                        ?>
                        
                    </div>
                </div>
            </div>
        </div>
        <?php } ?>

    </div>
    <a id="scroll-top"></a>

<?php wp_footer(); ?>

</body>
</html>
